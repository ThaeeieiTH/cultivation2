package com.cultivation.client.model;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class CultivationRenderState extends LivingEntityRenderState {
}
