package com.cultivation.item;

import com.cultivation.CultivationMod;
import com.cultivation.entity.ModEntities;
import com.cultivation.skill.SkillType;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.ItemLore;

/** All items added by the mod. Swords are usable at every cultivation level. */
public final class ModItems {
	// --- Skill manuals ---
	public static final Item QI_BOLT_MANUAL = manual("qi_bolt_manual", SkillType.QI_BOLT);
	public static final Item AZURE_SWORD_MANUAL = manual("azure_sword_manual", SkillType.AZURE_SWORD);

	public static final Item WIND_PALM_MANUAL = manual("wind_palm_manual", SkillType.WIND_PALM);
	public static final Item EARTH_SHOCK_MANUAL = manual("earth_shock_manual", SkillType.EARTH_SHOCK);
	public static final Item WIND_STEP_MANUAL = manual("wind_step_manual", SkillType.WIND_STEP);

	// --- First-tier swords (damage = total damage dealt, durability as specified) ---
	public static final Item PLAIN_IRON_SWORD = sword("plain_iron_sword", 5, 250, Rarity.COMMON,
		"กระบี่สามัญ", "กระบี่เหล็กพื้นฐานที่ช่างตีเหล็กทั่วไปสร้างขึ้น แข็งแรงและใช้งานง่าย");
	public static final Item RUSTY_SWORD = sword("rusty_sword", 4, 150, Rarity.COMMON,
		"กระบี่สามัญ", "กระบี่เก่าที่ผ่านการใช้งานมานาน ใบกระบี่มีสนิมและร่องรอยการสึกหรอ");
	public static final Item BRONZE_SWORD = sword("bronze_sword", 5, 220, Rarity.COMMON,
		"กระบี่สามัญ", "กระบี่ที่ตีขึ้นจากสำริด มีน้ำหนักสมดุลและเหมาะกับการฝึกกระบี่");
	public static final Item BLACK_IRON_SWORD = sword("black_iron_sword", 6, 280, Rarity.UNCOMMON,
		"กระบี่สามัญ", "กระบี่ที่ผ่านการตีขึ้นรูปด้วยเหล็กสีเข้ม มีความทนทานมากกว่ากระบี่ทั่วไป");
	public static final Item SILVER_SWORD = sword("silver_sword", 6, 240, Rarity.UNCOMMON,
		"กระบี่สามัญ", "กระบี่ใบสีเงินที่มีน้ำหนักเบา เหมาะสำหรับการฟาดฟันอย่างรวดเร็ว");

	// --- Tier 2-10 swords (weapon tier only; usable at every cultivation level) ---
	public static final Item JADE_GREEN_SWORD = sword("jade_green_sword", 6, 300, Rarity.UNCOMMON,
		"ระดับ 2: กระบี่หลอมปราณ  (ความหายาก: ทั่วไป)", "กระบี่หยกสีเขียว มีลวดลายปราณบนใบกระบี่");
	public static final Item WIND_EDGE_SWORD = sword("wind_edge_sword", 7, 320, Rarity.UNCOMMON,
		"ระดับ 2: กระบี่หลอมปราณ  (ความหายาก: ทั่วไป)", "กระบี่สีเงินอมฟ้า มีลายเส้นคล้ายสายลม");
	public static final Item AZURE_QI_SWORD = sword("azure_qi_sword", 9, 450, Rarity.RARE,
		"ระดับ 3: กระบี่วิญญาณ  (ความหายาก: หายาก)", "ใบกระบี่สีฟ้าเรืองแสง มีพลังปราณไหลเวียน");
	public static final Item MOLTEN_FLAME_SWORD = sword("molten_flame_sword", 10, 420, Rarity.RARE,
		"ระดับ 3: กระบี่วิญญาณ  (ความหายาก: หายาก)", "ใบกระบี่สีแดงส้ม มีลายเปลวเพลิง");
	public static final Item INDIGO_SPIRIT_SWORD = sword("indigo_spirit_sword", 13, 600, Rarity.RARE,
		"ระดับ 4: กระบี่ลี้ลับ  (ความหายาก: หายากมาก)", "กระบี่สีคราม มีประกายวิญญาณรอบใบกระบี่");
	public static final Item MOON_SWORD = sword("moon_sword", 12, 700, Rarity.RARE,
		"ระดับ 4: กระบี่ลี้ลับ  (ความหายาก: หายากมาก)", "ใบกระบี่สีเงิน มีลวดลายพระจันทร์");
	public static final Item PHANTOM_SHADOW_SWORD = sword("phantom_shadow_sword", 16, 800, Rarity.RARE,
		"ระดับ 5: กระบี่ปฐพี  (ความหายาก: ระดับสูง)", "กระบี่สีม่วงดำ มีเอฟเฟกต์เงามายา");
	public static final Item MYSTIC_THUNDER_SWORD = sword("mystic_thunder_sword", 18, 750, Rarity.RARE,
		"ระดับ 5: กระบี่ปฐพี  (ความหายาก: ระดับสูง)", "กระบี่สีม่วง มีลายสายฟ้าบนใบกระบี่");
	public static final Item MOUNTAIN_STONE_SWORD = sword("mountain_stone_sword", 21, 1000, Rarity.RARE,
		"ระดับ 6: กระบี่สวรรค์  (ความหายาก: ระดับสูง)", "กระบี่สีเทาหิน มีลวดลายหินผา");
	public static final Item EARTH_CORE_SWORD = sword("earth_core_sword", 23, 1100, Rarity.RARE,
		"ระดับ 6: กระบี่สวรรค์  (ความหายาก: ระดับสูง)", "กระบี่สีน้ำตาลทอง มีแก่นพลังปฐพีตรงกลาง");
	public static final Item HEAVEN_CLOUD_SWORD = sword("heaven_cloud_sword", 26, 1200, Rarity.EPIC,
		"ระดับ 7: กระบี่ราชัน  (ความหายาก: หายากมาก)", "กระบี่สีขาวฟ้า มีลายเมฆสวรรค์");
	public static final Item HEAVEN_THUNDER_SWORD = sword("heaven_thunder_sword", 28, 1150, Rarity.EPIC,
		"ระดับ 7: กระบี่ราชัน  (ความหายาก: หายากมาก)", "กระบี่สีทองฟ้า มีสายฟ้าสวรรค์");
	public static final Item DRAGON_MONARCH_SWORD = sword("dragon_monarch_sword", 32, 1400, Rarity.EPIC,
		"ระดับ 8: กระบี่จักรพรรดิ  (ความหายาก: ระดับตำนาน)", "กระบี่สีทอง มีลวดลายมังกร");
	public static final Item BLOOD_MONARCH_SWORD = sword("blood_monarch_sword", 34, 1300, Rarity.EPIC,
		"ระดับ 8: กระบี่จักรพรรดิ  (ความหายาก: ระดับตำนาน)", "กระบี่สีแดงเข้ม มีลายพลังโลหิต");
	public static final Item SKY_EMPEROR_SWORD = sword("sky_emperor_sword", 38, 1600, Rarity.EPIC,
		"ระดับ 9: กระบี่เซียน  (ความหายาก: ระดับตำนาน)", "กระบี่สีทองขาว มีลวดลายนภา");
	public static final Item VOID_EMPEROR_SWORD = sword("void_emperor_sword", 40, 1700, Rarity.EPIC,
		"ระดับ 9: กระบี่เซียน  (ความหายาก: ระดับตำนาน)", "กระบี่สีดำม่วง มีรอยแยกมิติบนใบกระบี่");
	public static final Item WIND_IMMORTAL_SWORD = sword("wind_immortal_sword", 44, 1900, Rarity.EPIC,
		"ระดับ 10: กระบี่เซียนสวรรค์  (ความหายาก: สมบัติเซียน)", "กระบี่สีฟ้าอ่อน มีพลังวายุหมุนรอบใบกระบี่");
	public static final Item ETERNAL_IMMORTAL_SWORD = sword("eternal_immortal_sword", 46, 2000, Rarity.EPIC,
		"ระดับ 10: กระบี่เซียนสวรรค์  (ความหายาก: สมบัติเซียน)", "กระบี่สีขาวทอง มีลวดลายพลังนิรันดร์");

	// --- Beast drops ---
	public static final Item WOLF_FANG = material("wolf_fang", "เขี้ยวหมาป่า", "เขี้ยวแหลมคมของหมาป่าวายุคราม");
	public static final Item WIND_CORE = material("wind_core", "แก่นวายุ", "แก่นพลังลมที่เหลือจากหมาป่าวายุคราม");
	public static final Item STONE_FANG = material("stone_fang", "เขี้ยวศิลา", "เขี้ยวแข็งดั่งหินของหมูป่าเกราะศิลา");
	public static final Item STONE_ARMOR_SHARD = material("stone_armor_shard", "เศษเกราะหิน", "เศษเกราะหินที่หลุดจากหมูป่าเกราะศิลา");
	public static final Item FLAME_CORE = material("flame_core", "แก่นเพลิง", "แก่นพลังเพลิงที่ยังอุ่นอยู่ จากจิ้งจอกเพลิง");
	public static final Item SPIRIT_FOX_FUR = material("spirit_fox_fur", "ขนจิ้งจอกอสูร", "ขนนุ่มสีส้มแดงของจิ้งจอกเพลิง");

	// --- Spawn eggs (one per spirit beast; they spawn the matching entity) ---
	public static final Item BLUE_WIND_WOLF_SPAWN_EGG = register("blue_wind_wolf_spawn_egg",
		SpawnEggItem::new, new Item.Properties().spawnEgg(ModEntities.BLUE_WIND_WOLF));
	public static final Item STONE_ARMOR_BOAR_SPAWN_EGG = register("stone_armor_boar_spawn_egg",
		SpawnEggItem::new, new Item.Properties().spawnEgg(ModEntities.STONE_ARMOR_BOAR));
	public static final Item FLAME_FOX_SPAWN_EGG = register("flame_fox_spawn_egg",
		SpawnEggItem::new, new Item.Properties().spawnEgg(ModEntities.FLAME_FOX));

	private ModItems() {
	}

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties properties) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, CultivationMod.id(name));
		return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(properties.setId(key)));
	}

	private static Item.Properties withLore(Item.Properties properties, String... lines) {
		List<Component> components = new ArrayList<>();
		for (String line : lines) {
			components.add(Component.literal(line).withStyle(ChatFormatting.GRAY));
		}
		return properties.component(DataComponents.LORE, new ItemLore(components));
	}

	private static Item manual(String name, SkillType skill) {
		Item.Properties properties = withLore(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON),
			"วิชา: " + skill.thaiName() + " (" + skill.kind() + ")",
			"ระดับคัมภีร์: สร้างลมปราณ",
			"ระดับพลังที่ต้องมี: สร้างลมปราณ",
			skill.description(),
			"คลิกขวาเพื่อเรียนรู้วิชา");
		return register(name, props -> new ManualItem(props, skill), properties);
	}

	private static Item sword(String name, int damage, int durability, Rarity rarity, String tier, String description) {
		ToolMaterial material = new ToolMaterial(
			BlockTags.INCORRECT_FOR_IRON_TOOL, durability, 6.0f, 0.0f, 10, ItemTags.IRON_TOOL_MATERIALS);
		// Player base damage is 1, so the sword contributes (damage - 1).
		Item.Properties properties = withLore(new Item.Properties().sword(material, damage - 1.0f, -2.4f).rarity(rarity),
			"ระดับ: " + tier,
			"ความเสียหาย: " + damage + "  ความทนทาน: " + durability,
			description,
			"ผู้ฝึกตนทุกระดับพลังใช้ได้");
		return register(name, Item::new, properties);
	}

	private static Item material(String name, String thaiName, String description) {
		return register(name, Item::new, withLore(new Item.Properties(), description));
	}

	public static void init() {
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
			tab.accept(PLAIN_IRON_SWORD);
			tab.accept(RUSTY_SWORD);
			tab.accept(BRONZE_SWORD);
			tab.accept(BLACK_IRON_SWORD);
			tab.accept(SILVER_SWORD);
			tab.accept(JADE_GREEN_SWORD);
			tab.accept(WIND_EDGE_SWORD);
			tab.accept(AZURE_QI_SWORD);
			tab.accept(MOLTEN_FLAME_SWORD);
			tab.accept(INDIGO_SPIRIT_SWORD);
			tab.accept(MOON_SWORD);
			tab.accept(PHANTOM_SHADOW_SWORD);
			tab.accept(MYSTIC_THUNDER_SWORD);
			tab.accept(MOUNTAIN_STONE_SWORD);
			tab.accept(EARTH_CORE_SWORD);
			tab.accept(HEAVEN_CLOUD_SWORD);
			tab.accept(HEAVEN_THUNDER_SWORD);
			tab.accept(DRAGON_MONARCH_SWORD);
			tab.accept(BLOOD_MONARCH_SWORD);
			tab.accept(SKY_EMPEROR_SWORD);
			tab.accept(VOID_EMPEROR_SWORD);
			tab.accept(WIND_IMMORTAL_SWORD);
			tab.accept(ETERNAL_IMMORTAL_SWORD);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tab -> {
			tab.accept(QI_BOLT_MANUAL);
			tab.accept(AZURE_SWORD_MANUAL);
			tab.accept(WIND_PALM_MANUAL);
			tab.accept(EARTH_SHOCK_MANUAL);
			tab.accept(WIND_STEP_MANUAL);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.SPAWN_EGGS).register(tab -> {
			tab.accept(BLUE_WIND_WOLF_SPAWN_EGG);
			tab.accept(STONE_ARMOR_BOAR_SPAWN_EGG);
			tab.accept(FLAME_FOX_SPAWN_EGG);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(tab -> {
			tab.accept(WOLF_FANG);
			tab.accept(WIND_CORE);
			tab.accept(STONE_FANG);
			tab.accept(STONE_ARMOR_SHARD);
			tab.accept(FLAME_CORE);
			tab.accept(SPIRIT_FOX_FUR);
		});
	}
}
