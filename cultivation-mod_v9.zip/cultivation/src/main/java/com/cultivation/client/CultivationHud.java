package com.cultivation.client;

import com.cultivation.CultivationMod;
import com.cultivation.network.CultivationSyncPayload;
import com.cultivation.network.SkillSyncPayload;
import com.cultivation.progression.CultivationRules;
import com.cultivation.skill.SkillType;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Permanent HUD: realm, sub-stage, experience bar, Qi bar and the selected skill name. Skill
 * proficiency is deliberately not shown here (see the N screen).
 */
public final class CultivationHud {
	private static final int X = 10;
	private static final int Y = 10;
	private static final int WIDTH = 150;
	private static final int BAR_HEIGHT = 6;

	private static final int PANEL_BG = 0xA0000000;
	private static final int PANEL_BORDER = 0xFF6B5B2A;
	private static final int BAR_BG = 0xFF1B1B1B;
	private static final int BAR_BORDER = 0xFF000000;
	private static final int EXP_COLOR = 0xFFE8B923;
	private static final int QI_COLOR = 0xFF3FA7FF;
	private static final int TITLE_COLOR = 0xFFFFD75E;
	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int HINT_COLOR = 0xFF7CFF7C;
	private static final int SKILL_COLOR = 0xFF9FE8FF;
	private static final int HEALTH_COLOR = 0xFFFF6B6B;

	private CultivationHud() {
	}

	public static void register() {
		HudElementRegistry.addLast(CultivationMod.id("cultivation_hud"), CultivationHud::render);
	}

	private static String number(long value) {
		return String.format(Locale.ROOT, "%,d", value);
	}

	private static void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		CultivationSyncPayload state = ClientCultivationState.get();
		if (state == null) {
			return;
		}
		Font font = Minecraft.getInstance().font;
		boolean max = state.isMaxState();
		boolean ready = state.isReadyToAdvance();
		boolean meditating = ClientMeditationState.isActive();
		int extra = meditating ? 24 : 0;
		int contentHeight = (ready ? 84 : 72) + extra;

		int left = X - 4;
		int top = Y - 4;
		int right = X + WIDTH + 4;
		int bottom = Y + contentHeight + 4;
		graphics.fill(left, top, right, bottom, PANEL_BG);
		graphics.outline(left, top, right - left, bottom - top, PANEL_BORDER);

		graphics.text(font, CultivationRules.displayName(state.realm(), state.stage()), X, Y, TITLE_COLOR, true);

		String expText = max
			? "ประสบการณ์: สูงสุด (MAX)"
			: "ประสบการณ์: " + number(state.experience()) + " / " + number(state.required());
		graphics.text(font, expText, X, Y + 12, TEXT_COLOR, true);
		double expRatio = max ? 1.0 : (state.required() <= 0L ? 0.0 : (double) state.experience() / state.required());
		drawBar(graphics, X, Y + 23, WIDTH, expRatio, EXP_COLOR);

		graphics.text(font, "ลมปราณ: " + number(state.qi()) + " / " + number(state.maxQi()), X, Y + 33, TEXT_COLOR, true);
		double qiRatio = state.maxQi() <= 0 ? 0.0 : (double) state.qi() / state.maxQi();
		drawBar(graphics, X, Y + 44, WIDTH, qiRatio, QI_COLOR);

		SkillType selected = SkillType.byId(ClientSkillState.get().selected());
		String skillText = "วิชา: " + (selected == null ? "-" : selected.thaiName());
		var player = Minecraft.getInstance().player;
		if (player != null) {
			int health = (int) Math.ceil(player.getHealth());
			int maxHealth = (int) Math.ceil(player.getMaxHealth());
			graphics.text(font, "เลือด " + health + " / " + maxHealth, X, Y + 53, HEALTH_COLOR, true);
		}
		graphics.text(font, skillText, X, Y + 64, SKILL_COLOR, true);

		if (meditating) {
			graphics.text(font, "กำลังนั่งฝึกพลังปราณ", X, Y + 75, HINT_COLOR, true);
			SkillSyncPayload skills = ClientSkillState.get();
			int proficiency = selected == null ? -1 : skills.proficiency(selected.id());
			String line = (selected != null && proficiency >= 0 && proficiency < SkillType.MAX_PROFICIENCY)
				? selected.thaiName() + " " + proficiency + " / " + SkillType.MAX_PROFICIENCY
				: "ฝึกพลังปราณพื้นฐาน";
			graphics.text(font, line, X, Y + 86, SKILL_COLOR, true);
		}

		if (ready) {
			String hint = state.stage() >= CultivationRules.LAST_STAGE
				? "พร้อมทะลวง: กด M"
				: "พร้อมเลื่อนขั้น: กด M";
			graphics.text(font, hint, X, Y + 75 + extra, HINT_COLOR, true);
		}
	}

	private static void drawBar(GuiGraphicsExtractor graphics, int x, int y, int width, double ratio, int color) {
		graphics.fill(x, y, x + width, y + BAR_HEIGHT, BAR_BG);
		int filled = (int) Math.round(width * Math.clamp(ratio, 0.0, 1.0));
		if (filled > 0) {
			graphics.fill(x, y, x + filled, y + BAR_HEIGHT, color);
		}
		graphics.outline(x, y, width, BAR_HEIGHT, BAR_BORDER);
	}
}
