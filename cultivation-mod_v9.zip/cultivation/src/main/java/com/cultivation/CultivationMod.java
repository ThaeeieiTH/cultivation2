package com.cultivation;

import com.cultivation.activity.CultivationActivities;
import com.cultivation.activity.CultivationTicker;
import com.cultivation.command.CultivationCommands;
import com.cultivation.data.CultivationAttachments;
import com.cultivation.entity.BeastSpawner;
import com.cultivation.entity.ModEntities;
import com.cultivation.item.ModItems;
import com.cultivation.loot.ModLoot;
import com.cultivation.network.CultivationNetworking;
import com.cultivation.skill.MeditationService;
import com.cultivation.skill.SkillAttachments;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CultivationMod implements ModInitializer {
	public static final String MOD_ID = "cultivation";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		CultivationAttachments.init();
		SkillAttachments.init();
		ModItems.init();
		ModEntities.init();
		BeastSpawner.register();
		ModLoot.register();
		CultivationNetworking.registerPayloads();
		CultivationNetworking.registerEvents();
		CultivationCommands.register();
		CultivationActivities.register();
		CultivationTicker.register();
		MeditationService.register();
		LOGGER.info("Cultivation mod initialised");
	}
}
