package com.cultivation.network;

import com.cultivation.CultivationMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server request: keyboard keys and touch buttons both send this. */
public record ActionPayload(int action) implements CustomPacketPayload {
	public static final int BREAKTHROUGH = 0;
	public static final int NEXT_SKILL = 1;
	public static final int USE_SKILL = 2;
	public static final int TOGGLE_MEDITATION = 3;

	public static final CustomPacketPayload.Type<ActionPayload> TYPE =
		new CustomPacketPayload.Type<>(CultivationMod.id("action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, ActionPayload> CODEC = StreamCodec.composite(
		ByteBufCodecs.VAR_INT, ActionPayload::action,
		ActionPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
