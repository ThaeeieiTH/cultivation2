# Cultivation (Fabric, Minecraft 26.2)

Mod ID: `cultivation` | Minecraft 26.2 | Fabric Loader 0.20.1 | Fabric API 0.161.0+26.2 | Java 25

## Build
- GitHub: push this folder to a repo; the `build` workflow (Actions tab) builds it and uploads the jar as an artifact.
- Local: install JDK 25 and Gradle 9.3+, then run `gradle build`. The jar is in `build/libs/`
  (use `cultivation-1.0.0.jar`, not the `-sources` jar). Optionally run `gradle wrapper` once to create ./gradlew.

## Gameplay
- 10 realms x 4 sub-stages (ขั้นต้น / ขั้นกลาง / ขั้นปลาย / ขั้นสมบูรณ์).
- Gain cultivation experience by killing monsters, or by meditating (sneak while standing still on the ground).
- When the experience bar is full: `/cultivation advance` (sub-stage) or, at ขั้นสมบูรณ์, `/cultivation breakthrough` (costs 50% of max Qi).
- `/cultivation` shows status. เซียนสวรรค์ ขั้นสมบูรณ์ is the maximum state.
- Qi regenerates 1% of max per second (x5 while meditating) and max Qi grows with every sub-stage.

## Code layout
- `data/` persistence (Fabric data attachment, codec) and server-side store
- `progression/` realms, rules, progression service
- `qi/` Qi service (add / consume / regenerate)
- `activity/` experience sources and the per-second ticker
- `network/` server -> client sync packet
- `command/` /cultivation commands
- `client/` HUD rendering and client state
- `CultivationConfig` tuning constants
