package com.cultivation.progression;

/** The 4 sub-stages of every realm, in order. */
public enum CultivationStage {
	EARLY("ขั้นต้น"),
	MIDDLE("ขั้นกลาง"),
	LATE("ขั้นปลาย"),
	PERFECTION("ขั้นสมบูรณ์");

	private static final CultivationStage[] VALUES = values();
	public static final int COUNT = VALUES.length;

	private final String thaiName;

	CultivationStage(String thaiName) {
		this.thaiName = thaiName;
	}

	public String thaiName() {
		return thaiName;
	}

	public static CultivationStage byIndex(int index) {
		return VALUES[Math.clamp(index, 0, COUNT - 1)];
	}
}
