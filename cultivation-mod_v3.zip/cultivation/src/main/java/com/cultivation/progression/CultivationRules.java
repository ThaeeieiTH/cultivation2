package com.cultivation.progression;

import com.cultivation.CultivationConfig;

/** Pure tables/formulas for realms, experience and Qi. No Minecraft dependencies. */
public final class CultivationRules {
	public static final int LAST_REALM = CultivationRealm.COUNT - 1;
	public static final int LAST_STAGE = CultivationStage.COUNT - 1;

	private CultivationRules() {
	}

	private static int flatIndex(int realm, int stage) {
		return realm * CultivationStage.COUNT + stage;
	}

	/** Experience needed to fill the given sub-stage. */
	public static long requiredExperience(int realm, int stage) {
		double value = CultivationConfig.EXP_BASE * Math.pow(CultivationConfig.EXP_GROWTH, flatIndex(realm, stage));
		return Math.max(1L, Math.round(value));
	}

	/** Maximum Qi at the given sub-stage. Grows as the player advances. */
	public static int maxQi(int realm, int stage) {
		double value = CultivationConfig.QI_BASE * Math.pow(CultivationConfig.QI_GROWTH, flatIndex(realm, stage));
		return (int) Math.max(1.0, Math.min(value, (double) CultivationConfig.QI_HARD_CAP));
	}

	public static int qiRegenPerSecond(int maxQi) {
		return Math.max(1, maxQi / CultivationConfig.QI_REGEN_DIVISOR);
	}

	/** Qi spent to break through from the perfection stage of the given realm. */
	public static int breakthroughQiCost(int realm) {
		return Math.max(1, maxQi(realm, LAST_STAGE) / CultivationConfig.BREAKTHROUGH_QI_DIVISOR);
	}

	/** The single final state: Heavenly Immortal, Perfection. Nothing lies beyond it. */
	public static boolean isMaxState(int realm, int stage) {
		return realm >= LAST_REALM && stage >= LAST_STAGE;
	}

	public static String displayName(int realm, int stage) {
		return CultivationRealm.byIndex(realm).thaiName() + " " + CultivationStage.byIndex(stage).thaiName();
	}
}
