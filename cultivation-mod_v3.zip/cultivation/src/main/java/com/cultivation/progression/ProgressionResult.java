package com.cultivation.progression;

public enum ProgressionResult {
	ADVANCED,
	BROKE_THROUGH,
	EXPERIENCE_NOT_FULL,
	QI_NOT_ENOUGH,
	USE_BREAKTHROUGH,
	USE_ADVANCE,
	MAX_REACHED
}
