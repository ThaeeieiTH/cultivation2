package com.cultivation.progression;

/** The 10 cultivation realms, in order. Do not add, remove or reorder. */
public enum CultivationRealm {
	QI_BUILDING("สร้างลมปราณ"),
	FOUNDATION("สร้างรากฐาน"),
	GOLDEN_CORE("ก่อแก่นทองคำ"),
	NASCENT_SOUL("ก่อกำเนิดวิญญาณ"),
	DEITY_TRANSFORMATION("แปรเทพ"),
	VOID_REFINEMENT("หลอมสุญตา"),
	MAHAYANA("มหายาน"),
	TRIBULATION("ข้ามเคราะห์สวรรค์"),
	TRUE_IMMORTAL("เซียนแท้"),
	HEAVENLY_IMMORTAL("เซียนสวรรค์");

	private static final CultivationRealm[] VALUES = values();
	public static final int COUNT = VALUES.length;

	private final String thaiName;

	CultivationRealm(String thaiName) {
		this.thaiName = thaiName;
	}

	public String thaiName() {
		return thaiName;
	}

	public static CultivationRealm byIndex(int index) {
		return VALUES[Math.clamp(index, 0, COUNT - 1)];
	}
}
