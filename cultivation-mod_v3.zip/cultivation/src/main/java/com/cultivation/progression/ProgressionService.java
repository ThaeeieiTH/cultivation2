package com.cultivation.progression;

import com.cultivation.data.CultivationData;
import com.cultivation.data.CultivationStore;
import net.minecraft.server.level.ServerPlayer;

/**
 * Server-side cultivation progression. Experience fills the current sub-stage and stops at the
 * requirement; the player must explicitly advance (or break through at the perfection stage), so
 * sub-stages are never skipped automatically.
 */
public final class ProgressionService {
	private ProgressionService() {
	}

	/**
	 * Adds cultivation experience, capped at the current sub-stage requirement.
	 *
	 * @return the experience actually gained
	 */
	public static long addExperience(ServerPlayer player, long amount) {
		if (amount <= 0L) {
			return 0L;
		}
		CultivationData data = CultivationStore.get(player);
		if (data.isMaxState()) {
			return 0L;
		}
		long required = data.requiredExperience();
		long target = Math.min(required, data.experience() + amount);
		long gained = target - data.experience();
		if (gained > 0L) {
			CultivationStore.set(player, data.withExperience(target));
		}
		return gained;
	}

	/** Moves to the next sub-stage within the current realm. */
	public static ProgressionResult tryAdvanceStage(ServerPlayer player) {
		CultivationData data = CultivationStore.get(player);
		if (data.isMaxState()) {
			return ProgressionResult.MAX_REACHED;
		}
		if (data.stage() >= CultivationRules.LAST_STAGE) {
			return ProgressionResult.USE_BREAKTHROUGH;
		}
		if (data.experience() < data.requiredExperience()) {
			return ProgressionResult.EXPERIENCE_NOT_FULL;
		}
		int nextStage = data.stage() + 1;
		CultivationStore.set(player, new CultivationData(
			data.realm(), nextStage, 0L, data.qi(), CultivationRules.maxQi(data.realm(), nextStage)));
		return ProgressionResult.ADVANCED;
	}

	/** Breaks through from the perfection stage into the first stage of the next realm. */
	public static ProgressionResult tryBreakthrough(ServerPlayer player) {
		CultivationData data = CultivationStore.get(player);
		if (data.isMaxState()) {
			return ProgressionResult.MAX_REACHED;
		}
		if (data.stage() < CultivationRules.LAST_STAGE) {
			return ProgressionResult.USE_ADVANCE;
		}
		if (data.experience() < data.requiredExperience()) {
			return ProgressionResult.EXPERIENCE_NOT_FULL;
		}
		int cost = CultivationRules.breakthroughQiCost(data.realm());
		if (data.qi() < cost) {
			return ProgressionResult.QI_NOT_ENOUGH;
		}
		int nextRealm = data.realm() + 1;
		CultivationStore.set(player, new CultivationData(
			nextRealm, 0, 0L, data.qi() - cost, CultivationRules.maxQi(nextRealm, 0)));
		return ProgressionResult.BROKE_THROUGH;
	}
}
