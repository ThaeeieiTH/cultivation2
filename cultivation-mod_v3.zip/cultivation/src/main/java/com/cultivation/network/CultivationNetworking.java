package com.cultivation.network;

import com.cultivation.data.CultivationStore;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;

/** Server-side synchronisation of cultivation data to the owning client. */
public final class CultivationNetworking {
	private CultivationNetworking() {
	}

	public static void registerPayloads() {
		PayloadTypeRegistry.clientboundPlay().register(CultivationSyncPayload.TYPE, CultivationSyncPayload.CODEC);
	}

	public static void registerEvents() {
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> send(handler.getPlayer()));
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> send(newPlayer));
	}

	public static void send(ServerPlayer player) {
		ServerPlayNetworking.send(player, CultivationSyncPayload.from(CultivationStore.get(player)));
	}
}
