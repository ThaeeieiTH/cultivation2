package com.cultivation.network;

import com.cultivation.CultivationMod;
import com.cultivation.data.CultivationData;
import com.cultivation.progression.CultivationRules;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client snapshot of the player's cultivation state, used by the HUD. */
public record CultivationSyncPayload(int realm, int stage, long experience, long required, int qi, int maxQi)
	implements CustomPacketPayload {

	public static final CustomPacketPayload.Type<CultivationSyncPayload> TYPE =
		new CustomPacketPayload.Type<>(CultivationMod.id("sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, CultivationSyncPayload> CODEC = StreamCodec.composite(
		ByteBufCodecs.VAR_INT, CultivationSyncPayload::realm,
		ByteBufCodecs.VAR_INT, CultivationSyncPayload::stage,
		ByteBufCodecs.VAR_LONG, CultivationSyncPayload::experience,
		ByteBufCodecs.VAR_LONG, CultivationSyncPayload::required,
		ByteBufCodecs.VAR_INT, CultivationSyncPayload::qi,
		ByteBufCodecs.VAR_INT, CultivationSyncPayload::maxQi,
		CultivationSyncPayload::new
	);

	public static CultivationSyncPayload from(CultivationData data) {
		return new CultivationSyncPayload(
			data.realm(), data.stage(), data.experience(), data.requiredExperience(), data.qi(), data.maxQi());
	}

	public boolean isMaxState() {
		return CultivationRules.isMaxState(realm, stage);
	}

	public boolean isReadyToAdvance() {
		return !isMaxState() && experience >= required;
	}

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
