package com.cultivation.command;

import com.cultivation.data.CultivationData;
import com.cultivation.data.CultivationStore;
import com.cultivation.progression.CultivationRules;
import com.cultivation.progression.ProgressionResult;
import com.cultivation.progression.ProgressionService;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Locale;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * /cultivation            - show status
 * /cultivation advance     - move to the next sub-stage (experience must be full)
 * /cultivation breakthrough - enter the next realm from the perfection stage
 */
public final class CultivationCommands {
	private CultivationCommands() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
			dispatcher.register(Commands.literal("cultivation")
				.executes(context -> status(context.getSource()))
				.then(Commands.literal("status").executes(context -> status(context.getSource())))
				.then(Commands.literal("advance").executes(context -> advance(context.getSource())))
				.then(Commands.literal("breakthrough").executes(context -> breakthrough(context.getSource())))
			));
	}

	private static String number(long value) {
		return String.format(Locale.ROOT, "%,d", value);
	}

	private static void say(ServerPlayer player, String text) {
		player.sendSystemMessage(Component.literal(text));
	}

	private static int status(CommandSourceStack source) throws CommandSyntaxException {
		ServerPlayer player = source.getPlayerOrException();
		CultivationData data = CultivationStore.get(player);
		say(player, "ระดับการฝึกตน: " + CultivationRules.displayName(data.realm(), data.stage())
			+ (data.isMaxState() ? " (สูงสุด)" : ""));
		if (data.isMaxState()) {
			say(player, "ประสบการณ์: สูงสุด");
		} else {
			say(player, "ประสบการณ์: " + number(data.experience()) + " / " + number(data.requiredExperience()));
		}
		say(player, "ลมปราณ: " + number(data.qi()) + " / " + number(data.maxQi()));
		if (data.isReadyToAdvance()) {
			if (data.stage() >= CultivationRules.LAST_STAGE) {
				say(player, "พร้อมทะลวงขั้นใหญ่ (ใช้ลมปราณ " + number(CultivationRules.breakthroughQiCost(data.realm()))
					+ ") พิมพ์ /cultivation breakthrough");
			} else {
				say(player, "พร้อมเลื่อนขั้นย่อย พิมพ์ /cultivation advance");
			}
		}
		return 1;
	}

	private static int advance(CommandSourceStack source) throws CommandSyntaxException {
		ServerPlayer player = source.getPlayerOrException();
		ProgressionResult result = ProgressionService.tryAdvanceStage(player);
		CultivationData data = CultivationStore.get(player);
		switch (result) {
			case ADVANCED -> say(player, "เลื่อนขั้นสำเร็จ! ตอนนี้คือ " + CultivationRules.displayName(data.realm(), data.stage()));
			case EXPERIENCE_NOT_FULL -> say(player, "ประสบการณ์ยังไม่เต็ม ("
				+ number(data.experience()) + " / " + number(data.requiredExperience()) + ")");
			case USE_BREAKTHROUGH -> say(player, "อยู่ขั้นสมบูรณ์แล้ว ต้องทะลวงด้วย /cultivation breakthrough");
			case MAX_REACHED -> say(player, "คุณอยู่ขั้นสูงสุดแล้ว");
			default -> say(player, "ไม่สามารถเลื่อนขั้นได้");
		}
		return result == ProgressionResult.ADVANCED ? 1 : 0;
	}

	private static int breakthrough(CommandSourceStack source) throws CommandSyntaxException {
		ServerPlayer player = source.getPlayerOrException();
		ProgressionResult result = ProgressionService.tryBreakthrough(player);
		CultivationData data = CultivationStore.get(player);
		switch (result) {
			case BROKE_THROUGH -> say(player, "ทะลวงสำเร็จ! เข้าสู่ " + CultivationRules.displayName(data.realm(), data.stage()));
			case EXPERIENCE_NOT_FULL -> say(player, "ประสบการณ์ยังไม่เต็ม ("
				+ number(data.experience()) + " / " + number(data.requiredExperience()) + ")");
			case QI_NOT_ENOUGH -> say(player, "ลมปราณไม่พอสำหรับทะลวง ต้องใช้ "
				+ number(CultivationRules.breakthroughQiCost(data.realm())) + " (มี " + number(data.qi()) + ")");
			case USE_ADVANCE -> say(player, "ยังไม่ถึงขั้นสมบูรณ์ ใช้ /cultivation advance เพื่อเลื่อนขั้นย่อย");
			case MAX_REACHED -> say(player, "คุณอยู่ขั้นสูงสุดแล้ว");
			default -> say(player, "ไม่สามารถทะลวงได้");
		}
		return result == ProgressionResult.BROKE_THROUGH ? 1 : 0;
	}
}
