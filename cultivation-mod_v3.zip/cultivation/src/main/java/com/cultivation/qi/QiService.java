package com.cultivation.qi;

import com.cultivation.data.CultivationData;
import com.cultivation.data.CultivationStore;
import com.cultivation.progression.CultivationRules;
import net.minecraft.server.level.ServerPlayer;

/** Server-side Qi management, kept separate from cultivation experience. */
public final class QiService {
	private QiService() {
	}

	public static int getQi(ServerPlayer player) {
		return CultivationStore.get(player).qi();
	}

	public static int getMaxQi(ServerPlayer player) {
		return CultivationStore.get(player).maxQi();
	}

	/**
	 * Adds Qi, never exceeding maximum Qi.
	 *
	 * @return the amount of Qi actually added
	 */
	public static int addQi(ServerPlayer player, int amount) {
		if (amount <= 0) {
			return 0;
		}
		CultivationData data = CultivationStore.get(player);
		long target = Math.min((long) data.qi() + amount, data.maxQi());
		int added = (int) (target - data.qi());
		if (added > 0) {
			CultivationStore.set(player, data.withQi((int) target));
		}
		return added;
	}

	/**
	 * Consumes Qi if the player has enough. Qi never becomes negative.
	 *
	 * @return true if the Qi was consumed (a zero amount always succeeds), false if the amount is
	 *         negative or the player does not have enough Qi
	 */
	public static boolean consumeQi(ServerPlayer player, int amount) {
		if (amount < 0) {
			return false;
		}
		if (amount == 0) {
			return true;
		}
		CultivationData data = CultivationStore.get(player);
		if (data.qi() < amount) {
			return false;
		}
		CultivationStore.set(player, data.withQi(data.qi() - amount));
		return true;
	}

	/** One second of natural Qi regeneration. */
	public static void regenerate(ServerPlayer player, int multiplier) {
		CultivationData data = CultivationStore.get(player);
		addQi(player, CultivationRules.qiRegenPerSecond(data.maxQi()) * Math.max(1, multiplier));
	}
}
