package com.cultivation.data;

import com.cultivation.progression.CultivationRules;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * Immutable player progression snapshot. Every instance is normalised by the constructor, so
 * loaded or modified data can never be out of range (experience within the sub-stage requirement,
 * Qi between 0 and max Qi).
 */
public record CultivationData(int realm, int stage, long experience, int qi, int maxQi) {
	public static final Codec<CultivationData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
		Codec.INT.fieldOf("realm").forGetter(CultivationData::realm),
		Codec.INT.fieldOf("stage").forGetter(CultivationData::stage),
		Codec.LONG.fieldOf("experience").forGetter(CultivationData::experience),
		Codec.INT.fieldOf("qi").forGetter(CultivationData::qi),
		Codec.INT.fieldOf("max_qi").forGetter(CultivationData::maxQi)
	).apply(instance, CultivationData::new));

	public CultivationData {
		realm = Math.clamp(realm, 0, CultivationRules.LAST_REALM);
		stage = Math.clamp(stage, 0, CultivationRules.LAST_STAGE);
		long required = CultivationRules.requiredExperience(realm, stage);
		experience = CultivationRules.isMaxState(realm, stage) ? required : Math.clamp(experience, 0L, required);
		maxQi = Math.max(maxQi, CultivationRules.maxQi(realm, stage));
		qi = Math.clamp(qi, 0, maxQi);
	}

	public static CultivationData initial() {
		int max = CultivationRules.maxQi(0, 0);
		return new CultivationData(0, 0, 0L, max, max);
	}

	public long requiredExperience() {
		return CultivationRules.requiredExperience(realm, stage);
	}

	public boolean isMaxState() {
		return CultivationRules.isMaxState(realm, stage);
	}

	/** True when the sub-stage experience bar is full and the player is not at the final state. */
	public boolean isReadyToAdvance() {
		return !isMaxState() && experience >= requiredExperience();
	}

	public CultivationData withExperience(long newExperience) {
		return new CultivationData(realm, stage, newExperience, qi, maxQi);
	}

	public CultivationData withQi(int newQi) {
		return new CultivationData(realm, stage, experience, newQi, maxQi);
	}
}
