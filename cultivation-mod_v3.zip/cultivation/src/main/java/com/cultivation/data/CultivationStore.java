package com.cultivation.data;

import com.cultivation.network.CultivationNetworking;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Server-side access point for player data. Writes go through {@link #set}; changed players are
 * flagged and synchronised to their client once per tick by {@link #flush}.
 */
public final class CultivationStore {
	private static final Set<UUID> DIRTY = new HashSet<>();

	private CultivationStore() {
	}

	public static CultivationData get(ServerPlayer player) {
		return player.getAttachedOrCreate(CultivationAttachments.DATA);
	}

	public static void set(ServerPlayer player, CultivationData data) {
		if (data.equals(get(player))) {
			return;
		}
		player.setAttached(CultivationAttachments.DATA, data);
		DIRTY.add(player.getUUID());
	}

	/** Sends pending updates to clients. Call once per server tick. */
	public static void flush(MinecraftServer server) {
		if (DIRTY.isEmpty()) {
			return;
		}
		for (UUID id : DIRTY) {
			ServerPlayer player = server.getPlayerList().getPlayer(id);
			if (player != null) {
				CultivationNetworking.send(player);
			}
		}
		DIRTY.clear();
	}

	public static void forget(UUID id) {
		DIRTY.remove(id);
	}
}
