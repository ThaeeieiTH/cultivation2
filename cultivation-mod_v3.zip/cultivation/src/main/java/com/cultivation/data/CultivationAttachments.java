package com.cultivation.data;

import com.cultivation.CultivationMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

/** Persistence: player cultivation data is stored as a persistent Fabric data attachment. */
public final class CultivationAttachments {
	public static final AttachmentType<CultivationData> DATA = AttachmentRegistry.create(
		CultivationMod.id("player_data"),
		builder -> builder
			.initializer(CultivationData::initial)
			.persistent(CultivationData.CODEC)
			.copyOnDeath()
	);

	private CultivationAttachments() {
	}

	/** Forces class loading so the attachment is registered during mod initialisation. */
	public static void init() {
	}
}
