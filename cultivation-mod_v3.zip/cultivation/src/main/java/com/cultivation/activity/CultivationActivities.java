package com.cultivation.activity;

import com.cultivation.CultivationConfig;
import com.cultivation.data.CultivationStore;
import com.cultivation.progression.ProgressionService;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.MobCategory;

/** Cultivation activity: killing monsters grants cultivation experience. */
public final class CultivationActivities {
	private CultivationActivities() {
	}

	public static void register() {
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(source.getEntity() instanceof ServerPlayer player)) {
				return;
			}
			if (entity.getType().getCategory() != MobCategory.MONSTER) {
				return;
			}
			long required = CultivationStore.get(player).requiredExperience();
			long gain = Math.max(CultivationConfig.KILL_EXP_MIN, required / CultivationConfig.KILL_EXP_DIVISOR);
			ProgressionService.addExperience(player, gain);
		});
	}
}
