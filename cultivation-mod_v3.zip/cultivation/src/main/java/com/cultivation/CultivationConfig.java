package com.cultivation;

/** Tunable gameplay constants. */
public final class CultivationConfig {
	public static final int TICKS_PER_SECOND = 20;

	/** Experience curve: required = BASE * GROWTH ^ (realm * 4 + stage). */
	public static final double EXP_BASE = 100.0;
	public static final double EXP_GROWTH = 1.35;

	/** Qi curve: maxQi = BASE * GROWTH ^ (realm * 4 + stage). */
	public static final double QI_BASE = 100.0;
	public static final double QI_GROWTH = 1.30;
	public static final int QI_HARD_CAP = 1_000_000_000;

	/** Qi regenerates 1/REGEN_DIVISOR of max Qi every second (at least 1). */
	public static final int QI_REGEN_DIVISOR = 100;
	public static final int MEDITATION_QI_MULTIPLIER = 5;

	/** Breakthrough costs maxQi / BREAKTHROUGH_QI_DIVISOR. */
	public static final int BREAKTHROUGH_QI_DIVISOR = 2;

	/** Meditation (sneak while standing still) gives required/DIVISOR experience per second, min MIN. */
	public static final long MEDITATION_EXP_DIVISOR = 120L;
	public static final long MEDITATION_EXP_MIN = 2L;
	/** Squared distance (blocks) a player may move per second and still count as standing still. */
	public static final double MEDITATION_MAX_MOVE_SQ = 0.25;

	/** Killing a monster gives required/DIVISOR experience, min MIN. */
	public static final long KILL_EXP_DIVISOR = 25L;
	public static final long KILL_EXP_MIN = 5L;

	private CultivationConfig() {
	}
}
