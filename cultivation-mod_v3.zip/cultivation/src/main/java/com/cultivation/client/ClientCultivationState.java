package com.cultivation.client;

import com.cultivation.network.CultivationSyncPayload;

/** Latest cultivation snapshot received from the server. */
public final class ClientCultivationState {
	private static volatile CultivationSyncPayload current;

	private ClientCultivationState() {
	}

	public static CultivationSyncPayload get() {
		return current;
	}

	public static void set(CultivationSyncPayload payload) {
		current = payload;
	}

	public static void clear() {
		current = null;
	}
}
