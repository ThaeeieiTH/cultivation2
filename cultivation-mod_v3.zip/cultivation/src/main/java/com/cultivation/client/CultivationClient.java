package com.cultivation.client;

import com.cultivation.network.CultivationSyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public final class CultivationClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(CultivationSyncPayload.TYPE,
			(payload, context) -> ClientCultivationState.set(payload));
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientCultivationState.clear());
		CultivationHud.register();
	}
}
