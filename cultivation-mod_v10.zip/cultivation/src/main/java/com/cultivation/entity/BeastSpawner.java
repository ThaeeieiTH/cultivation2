package com.cultivation.entity;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

/**
 * The mod's own natural spawner for spirit beasts. It does not depend on vanilla spawn rules
 * (light, monster cap competition, biome spawn lists), so beasts reliably appear in survival.
 * Every 5 seconds each player in the Overworld gets a chance of a spawn 24-48 blocks away, in the
 * matching biomes, capped at 6 beasts within 64 blocks (so it never floods the world).
 */
public final class BeastSpawner {
	private static final int INTERVAL_TICKS = 100;
	private static final double ATTEMPT_CHANCE = 0.5;
	private static final int NEARBY_CAP = 6;
	private static final double CAP_RADIUS = 64.0;
	private static final int MIN_DISTANCE = 24;
	private static final int MAX_DISTANCE = 48;

	private BeastSpawner() {
	}

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(BeastSpawner::onTick);
	}

	private static void onTick(MinecraftServer server) {
		if (server.getTickCount() % INTERVAL_TICKS != 0) {
			return;
		}
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (player.isSpectator() || !player.isAlive()) {
				continue;
			}
			ServerLevel level = (ServerLevel) player.level();
			if (level.dimension() != Level.OVERWORLD || level.getDifficulty() == Difficulty.PEACEFUL) {
				continue;
			}
			trySpawn(level, player);
		}
	}

	private static void trySpawn(ServerLevel level, ServerPlayer player) {
		RandomSource random = level.random;
		if (random.nextDouble() > ATTEMPT_CHANCE) {
			return;
		}
		AABB area = player.getBoundingBox().inflate(CAP_RADIUS);
		if (level.getEntitiesOfClass(BeastEntity.class, area).size() >= NEARBY_CAP) {
			return;
		}
		double angle = random.nextDouble() * Math.PI * 2.0;
		double distance = MIN_DISTANCE + random.nextInt(MAX_DISTANCE - MIN_DISTANCE + 1);
		int x = Mth.floor(player.getX() + Math.cos(angle) * distance);
		int z = Mth.floor(player.getZ() + Math.sin(angle) * distance);
		BlockPos pos = surface(level, x, z);
		if (pos == null) {
			return;
		}
		EntityType<? extends BeastEntity> type = pick(level.getBiome(pos), random);
		if (type == null) {
			return;
		}
		int count = type == ModEntities.BLUE_WIND_WOLF ? 2 + random.nextInt(2) : 1;
		for (int i = 0; i < count; i++) {
			BlockPos at = i == 0 ? pos : surface(level, x + random.nextInt(7) - 3, z + random.nextInt(7) - 3);
			if (at != null) {
				type.spawn(level, at, EntitySpawnReason.NATURAL);
			}
		}
	}

	/** Top solid surface at x,z if the spot is loaded, dry and has two blocks of free space. */
	private static BlockPos surface(ServerLevel level, int x, int z) {
		if (!level.hasChunkAt(new BlockPos(x, 0, z))) {
			return null;
		}
		int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
		BlockPos pos = new BlockPos(x, y, z);
		BlockPos below = pos.below();
		BlockState ground = level.getBlockState(below);
		boolean free = level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
			&& level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty();
		if (ground.isFaceSturdy(level, below, Direction.UP) && free && level.getFluidState(pos).isEmpty()) {
			return pos;
		}
		return null;
	}

	private static EntityType<? extends BeastEntity> pick(Holder<Biome> biome, RandomSource random) {
		boolean forest = biome.is(BiomeTags.IS_FOREST);
		boolean taiga = biome.is(BiomeTags.IS_TAIGA);
		boolean mountain = biome.is(BiomeTags.IS_MOUNTAIN);
		boolean warm = biome.is(BiomeTags.IS_SAVANNA) || biome.is(BiomeTags.IS_BADLANDS);
		boolean grass = biome.is(Biomes.PLAINS) || biome.is(Biomes.MEADOW);
		int wolf = (forest || taiga || grass) ? 6 : 0;
		int boar = (forest || mountain || taiga) ? 4 : 0;
		int fox = warm ? 3 : (forest ? 1 : 0);
		int total = wolf + boar + fox;
		if (total <= 0) {
			return null;
		}
		int roll = random.nextInt(total);
		if (roll < wolf) {
			return ModEntities.BLUE_WIND_WOLF;
		}
		if (roll < wolf + boar) {
			return ModEntities.STONE_ARMOR_BOAR;
		}
		return ModEntities.FLAME_FOX;
	}
}
