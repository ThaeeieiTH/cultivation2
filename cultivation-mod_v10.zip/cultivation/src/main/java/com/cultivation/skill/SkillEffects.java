package com.cultivation.skill;

import com.cultivation.entity.EffectEntity;
import com.cultivation.entity.ModEntities;
import com.cultivation.entity.ShockwaveEntity;
import com.cultivation.entity.WindTrailEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Server-side effects of the earth-shock and wind-step skills. */
public final class SkillEffects {
	public static final double SHOCK_RADIUS = 4.0;
	public static final double DASH_DISTANCE = 5.0;

	private SkillEffects() {
	}

	/** ปราณสะเทือนปฐพี: damages and pushes away every living thing within 4 blocks. */
	public static void shockwave(ServerPlayer player, ServerLevel level, float damage) {
		ShockwaveEntity ring = new ShockwaveEntity(ModEntities.SHOCKWAVE, level);
		ring.setPos(player.getX(), player.getY(), player.getZ());
		level.addFreshEntity(ring);
		AABB area = player.getBoundingBox().inflate(SHOCK_RADIUS);
		for (Entity entity : level.getEntities(player, area, e -> e instanceof LivingEntity && e.isAlive() && !(e instanceof EffectEntity))) {
			LivingEntity target = (LivingEntity) entity;
			if (target.distanceToSqr(player) > SHOCK_RADIUS * SHOCK_RADIUS) {
				continue;
			}
			target.hurtServer(level, level.damageSources().playerAttack(player), damage);
			double dx = target.getX() - player.getX();
			double dz = target.getZ() - player.getZ();
			if (dx * dx + dz * dz > 1.0E-4) {
				target.knockback(0.8, -dx, -dz);
			}
			target.setDeltaMovement(target.getDeltaMovement().add(0.0, 0.25, 0.0));
		}
	}

	/**
	 * ก้าวพริบตาวายุ: furthest safe point up to 5 blocks ahead along the horizontal look direction.
	 * Scans in half-block steps and stops at the first obstruction, so the dash can never pass
	 * through walls. Returns null when no safe spot exists (the skill is then not used).
	 */
	public static Vec3 findDashDestination(ServerPlayer player, ServerLevel level) {
		Vec3 look = player.getLookAngle();
		Vec3 dir = new Vec3(look.x, 0.0, look.z);
		if (dir.lengthSqr() < 1.0E-4) {
			float yaw = player.getYRot() * 0.017453292f;
			dir = new Vec3(-Mth.sin(yaw), 0.0, Mth.cos(yaw));
		}
		dir = dir.normalize();
		Vec3 start = player.position();
		Vec3 best = null;
		for (double d = 0.5; d <= DASH_DISTANCE + 1.0E-6; d += 0.5) {
			Vec3 candidate = start.add(dir.scale(d));
			AABB box = player.getBoundingBox().move(candidate.x - start.x, 0.0, candidate.z - start.z);
			if (!level.noCollision(player, box)) {
				break;
			}
			if (isSafe(level, candidate)) {
				best = candidate;
			}
		}
		return best;
	}

	private static boolean isHazard(BlockState state) {
		return state.getFluidState().is(FluidTags.LAVA)
			|| state.is(Blocks.FIRE) || state.is(Blocks.SOUL_FIRE)
			|| state.is(Blocks.MAGMA_BLOCK) || state.is(Blocks.CACTUS) || state.is(Blocks.SWEET_BERRY_BUSH);
	}

	/** Needs solid ground within 3 blocks below and no lava, fire, magma or cactus. */
	private static boolean isSafe(ServerLevel level, Vec3 at) {
		if (isHazard(level.getBlockState(BlockPos.containing(at)))) {
			return false;
		}
		for (int dy = 0; dy <= 3; dy++) {
			BlockPos pos = BlockPos.containing(at.x, at.y - 0.1 - dy, at.z);
			BlockState state = level.getBlockState(pos);
			if (isHazard(state)) {
				return false;
			}
			if (state.isFaceSturdy(level, pos, Direction.UP)) {
				return true;
			}
		}
		return false;
	}

	public static void dash(ServerPlayer player, ServerLevel level, Vec3 destination) {
		Vec3 start = player.position();
		Vec3 delta = destination.subtract(start);
		double length = delta.length();
		float yaw = (float) (Mth.atan2(-delta.x, delta.z) * 57.29577951308232);
		int steps = Math.min(6, (int) Math.ceil(length));
		for (int i = 0; i <= steps; i++) {
			Vec3 at = start.add(delta.scale(steps == 0 ? 0.0 : (double) i / steps));
			WindTrailEntity trail = new WindTrailEntity(ModEntities.WIND_TRAIL, level);
			trail.setPos(at.x, at.y + 0.2, at.z);
			trail.setFacing(yaw, 0.0f);
			level.addFreshEntity(trail);
		}
		player.connection.teleport(destination.x, destination.y, destination.z, player.getYRot(), player.getXRot());
		player.resetFallDistance();
	}
}
