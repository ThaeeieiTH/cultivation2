package com.cultivation.aura;

import com.cultivation.CultivationMod;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

/** Persistent per-player aura on/off switch (display only). */
public final class AuraAttachments {
	public static final AttachmentType<Boolean> ENABLED = AttachmentRegistry.create(
		CultivationMod.id("aura_enabled"),
		builder -> builder
			.initializer(() -> false)
			.persistent(Codec.BOOL)
			.copyOnDeath()
	);

	private AuraAttachments() {
	}

	public static void init() {
	}
}
