package com.cultivation.aura;

import com.cultivation.data.CultivationData;
import com.cultivation.data.CultivationStore;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * Cultivation aura (H key). Purely visual: the server emits particles for every player whose aura
 * is on, using that player's real realm / sub-stage, so all nearby players see the same aura.
 * It never changes damage, defence or any status.
 */
public final class AuraService {
	private static final int INTERVAL_TICKS = 4;

	private AuraService() {
	}

	public static boolean isEnabled(ServerPlayer player) {
		return Boolean.TRUE.equals(player.getAttachedOrCreate(AuraAttachments.ENABLED));
	}

	public static void toggle(ServerPlayer player) {
		boolean enabled = !isEnabled(player);
		player.setAttached(AuraAttachments.ENABLED, enabled);
		player.sendSystemMessage(Component.literal(enabled ? "เปิดออร่าพลังปราณ" : "ปิดออร่าพลังปราณ"));
	}

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(AuraService::onTick);
	}

	private static void onTick(MinecraftServer server) {
		if (server.getTickCount() % INTERVAL_TICKS != 0) {
			return;
		}
		long time = server.getTickCount();
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (!isEnabled(player) || !player.isAlive() || player.isSpectator() || player.isInvisible()) {
				continue;
			}
			CultivationData data = CultivationStore.get(player);
			AuraEffects.emit((ServerLevel) player.level(), player, data.realm(), data.stage(), time);
		}
	}
}
