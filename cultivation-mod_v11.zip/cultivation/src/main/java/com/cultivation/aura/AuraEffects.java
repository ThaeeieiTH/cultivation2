package com.cultivation.aura;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

/**
 * Particle patterns of the 10 realm auras. Each realm has its own colours and a set of allowed
 * elements; the sub-stage decides which of those elements are active and how dense they are:
 * early = a few motes, middle = flowing streams, late = rings and waves, perfection = everything.
 * Particle counts per call are small and the aura is emitted only every 4 ticks.
 */
final class AuraEffects {
	private static final int MOTES = 1;
	private static final int SPARK = 2;
	private static final int SPIRAL = 4;
	private static final int FEET_RING = 8;
	private static final int CORE = 16;
	private static final int WISP = 32;
	private static final int FLAME = 64;
	private static final int WAVE = 128;
	private static final int RING2 = 256;
	private static final int HALO = 512;
	private static final int STARS = 1024;
	private static final int LIGHTNING = 2048;
	private static final int SHOULDER = 4096;
	private static final int LIGHT = 8192;
	private static final int ALL = 16383;

	private static final float DEG = 0.017453292f;

	/** Elements each realm may use (realm 1 has no big rings; realm 10 has everything). */
	private static final int[] REALM_MASK = {
		MOTES | SPARK | SPIRAL,
		MOTES | SPARK | SPIRAL | FEET_RING,
		MOTES | SPARK | SPIRAL | FEET_RING | CORE,
		MOTES | SPARK | SPIRAL | FEET_RING | WISP,
		MOTES | SPARK | SPIRAL | FEET_RING | FLAME | WAVE,
		MOTES | SPARK | SPIRAL | FEET_RING | RING2 | STARS,
		MOTES | SPARK | SPIRAL | FEET_RING | RING2 | FLAME | WAVE | SHOULDER,
		MOTES | SPARK | SPIRAL | FEET_RING | HALO | WAVE | LIGHTNING,
		MOTES | SPARK | SPIRAL | FEET_RING | RING2 | HALO | WAVE | LIGHT,
		ALL
	};

	// white-blue, emerald, gold, spirit violet, sky blue, void indigo, red-orange gold, thunder purple, white gold, heaven gold
	private static final int[] PRIMARY = {
		0xBFE8FF, 0x2ECC71, 0xFFC83D, 0x9B59FF, 0x33B5FF, 0x2A3FA8, 0xFF6A2B, 0x8A2BE2, 0xFFF2B0, 0xFFD24A
	};
	private static final int[] SECONDARY = {
		0xFFFFFF, 0xB6FFD2, 0xFFF0A8, 0xD9B8FF, 0xBFF0FF, 0x8FA6FF, 0xFFD36B, 0xE7CFFF, 0xFFFFFF, 0xFFF6C8
	};

	private AuraEffects() {
	}

	private static int stageMask(int stage) {
		int middle = MOTES | SPARK | SPIRAL | WISP | FLAME | LIGHTNING | SHOULDER;
		return switch (stage) {
			case 0 -> MOTES;
			case 1 -> middle;
			case 2 -> middle | FEET_RING | CORE | HALO | WAVE | RING2 | LIGHT;
			default -> ALL;
		};
	}

	private static int color(int realm, int index, long time, int primary) {
		if (realm == 9 && index % 2 == 1) {
			return Mth.hsvToRgb((float) (((time * 0.01) + index * 0.17) % 1.0), 0.55f, 1.0f);
		}
		return primary;
	}

	private static void dust(ServerLevel level, int color, float size, double x, double y, double z) {
		level.sendParticles(new DustParticleOptions(color, size), x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
	}

	private static void drift(ServerLevel level, ParticleOptions type, double x, double y, double z, double dy, double speed) {
		level.sendParticles(type, x, y, z, 0, 0.0, dy, 0.0, speed);
	}

	static void emit(ServerLevel level, ServerPlayer player, int realm, int stage, long time) {
		int mask = REALM_MASK[Math.clamp(realm, 0, 9)] & stageMask(stage);
		int primary = PRIMARY[Math.clamp(realm, 0, 9)];
		int secondary = SECONDARY[Math.clamp(realm, 0, 9)];
		double x = player.getX();
		double y = player.getY();
		double z = player.getZ();
		float height = player.getBbHeight();
		float yaw = player.getYRot() * DEG;
		double fx = -Mth.sin(yaw);
		double fz = Mth.cos(yaw);
		double rx = -fz;
		double rz = fx;
		RandomSource random = level.getRandom();
		double density = 0.6 + stage * 0.25;
		double pi = Math.PI;

		if ((mask & MOTES) != 0) {
			int n = Math.max(1, (int) Math.round((1 + realm / 3.0) * density));
			for (int i = 0; i < n; i++) {
				double a = random.nextDouble() * pi * 2.0;
				double r = 0.25 + random.nextDouble() * 0.5;
				dust(level, color(realm, i, time, primary), 0.9f, x + Math.cos(a) * r, y + random.nextDouble() * height * 0.9, z + Math.sin(a) * r);
			}
		}
		if ((mask & SPARK) != 0) {
			int n = Math.max(1, (int) Math.round(1.5 * density));
			for (int i = 0; i < n; i++) {
				drift(level, ParticleTypes.END_ROD, x + (random.nextDouble() - 0.5), y + 0.2 + random.nextDouble() * height,
					z + (random.nextDouble() - 0.5), 1.0, 0.03);
			}
		}
		if ((mask & SPIRAL) != 0) {
			for (int k = 0; k < 2; k++) {
				double a = time * 0.3 + k * pi;
				double hy = ((time * 0.04 + k * 0.5) % 1.0) * height;
				dust(level, color(realm, k, time, primary), 0.8f, x + Math.cos(a) * 0.75, y + hy, z + Math.sin(a) * 0.75);
			}
		}
		if ((mask & FEET_RING) != 0) {
			for (int k = 0; k < 4; k++) {
				double a = time * 0.12 + k * pi / 2.0;
				dust(level, color(realm, k, time, primary), 0.9f, x + Math.cos(a) * 0.9, y + 0.08, z + Math.sin(a) * 0.9);
			}
		}
		if ((mask & RING2) != 0) {
			for (int k = 0; k < 3; k++) {
				double a = -time * 0.15 + k * pi * 2.0 / 3.0;
				dust(level, secondary, 0.7f, x + Math.cos(a) * 0.65, y + height * 0.5, z + Math.sin(a) * 0.65);
			}
		}
		if ((mask & HALO) != 0) {
			for (int k = 0; k < 4; k++) {
				double a = time * 0.2 + k * pi / 2.0;
				dust(level, secondary, 0.7f, x + Math.cos(a) * 0.35, y + height + 0.25, z + Math.sin(a) * 0.35);
			}
		}
		if ((mask & CORE) != 0) {
			dust(level, secondary, 1.6f, x + (random.nextDouble() - 0.5) * 0.1, y + height * 0.6, z + (random.nextDouble() - 0.5) * 0.1);
			dust(level, primary, 1.0f, x, y + height * 0.6, z);
		}
		if ((mask & WISP) != 0) {
			int n = Math.max(1, (int) Math.round(1.2 * density));
			for (int i = 0; i < n; i++) {
				double dist = 0.4 + random.nextDouble() * 0.6;
				double side = (random.nextDouble() - 0.5) * 0.6;
				double py = y + 0.3 + random.nextDouble() * (height - 0.3);
				dust(level, primary, 1.1f, x - fx * dist + rx * side, py, z - fz * dist + rz * side);
				if (i == 0) {
					drift(level, ParticleTypes.SOUL, x - fx * dist + rx * side, py, z - fz * dist + rz * side, 1.0, 0.03);
				}
			}
		}
		if ((mask & FLAME) != 0) {
			ParticleOptions flame = realm == 4 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME;
			for (int s = -1; s <= 1; s += 2) {
				drift(level, flame, x + rx * 0.5 * s, y + height * 0.75, z + rz * 0.5 * s, 1.0, 0.02);
			}
			if (stage >= 2) {
				drift(level, flame, x - fx * 0.5, y + height * 0.6, z - fz * 0.5, 1.0, 0.02);
			}
		}
		if ((mask & WAVE) != 0) {
			double phase = (time % 48) / 48.0;
			if (phase < 0.85) {
				double radius = 0.5 + phase * 3.5;
				for (int k = 0; k < 6; k++) {
					double a = k * pi / 3.0 + time * 0.02;
					dust(level, secondary, 0.9f, x + Math.cos(a) * radius, y + 0.1, z + Math.sin(a) * radius);
				}
			}
		}
		if ((mask & STARS) != 0) {
			int n = Math.max(1, (int) Math.round(1.2 * density));
			for (int i = 0; i < n; i++) {
				drift(level, ParticleTypes.END_ROD, x + (random.nextDouble() - 0.5) * 3.0, y + random.nextDouble() * height * 1.3,
					z + (random.nextDouble() - 0.5) * 3.0, 0.2, 0.01);
			}
		}
		if ((mask & LIGHTNING) != 0 && time % 12 == 0) {
			for (int i = 0; i < 2; i++) {
				level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x + (random.nextDouble() - 0.5) * 1.2, y + random.nextDouble() * height,
					z + (random.nextDouble() - 0.5) * 1.2, 0, 0.0, 0.0, 0.0, 0.1);
			}
			dust(level, secondary, 1.0f, x + (random.nextDouble() - 0.5), y + random.nextDouble() * height, z + (random.nextDouble() - 0.5));
		}
		if ((mask & SHOULDER) != 0) {
			for (int s = -1; s <= 1; s += 2) {
				dust(level, secondary, 0.8f, x + rx * 0.45 * s, y + height * 0.85, z + rz * 0.45 * s);
			}
		}
		if ((mask & LIGHT) != 0) {
			// Halo of light behind the back (vertical disk).
			double cx = x - fx * 0.5;
			double cy = y + height * 0.65;
			double cz = z - fz * 0.5;
			for (int k = 0; k < 5; k++) {
				double a = time * 0.1 + k * pi * 2.0 / 5.0;
				double h = Math.cos(a) * 0.9;
				dust(level, color(realm, k, time, secondary), 0.9f, cx + rx * h, cy + Math.sin(a) * 0.9, cz + rz * h);
			}
		}
	}
}
