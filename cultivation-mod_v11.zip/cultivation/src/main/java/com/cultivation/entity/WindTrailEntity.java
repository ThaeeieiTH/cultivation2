package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Blue wind streak left behind by ก้าวพริบตาวายุ. */
public class WindTrailEntity extends TimedEffectEntity {
	public WindTrailEntity(EntityType<? extends WindTrailEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int lifetime() {
		return 10;
	}
}
