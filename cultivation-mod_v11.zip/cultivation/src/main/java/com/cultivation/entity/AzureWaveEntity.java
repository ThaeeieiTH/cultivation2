package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** กระบี่ปราณฟ้า: a crescent sword wave that cuts through everything on its path (about 20 blocks). */
public class AzureWaveEntity extends ProjectileEffect {
	public AzureWaveEntity(EntityType<? extends AzureWaveEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int chargeTicks() {
		return 4;
	}

	@Override
	protected double speed() {
		return 0.95;
	}

	@Override
	protected int maxFlightTicks() {
		return 21;
	}

	@Override
	protected boolean pierces() {
		return true;
	}
}
