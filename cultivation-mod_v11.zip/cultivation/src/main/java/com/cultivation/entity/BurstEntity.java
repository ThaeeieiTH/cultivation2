package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Short-lived impact burst; dissolves after 8 ticks. */
public class BurstEntity extends EffectEntity {
	public static final int LIFETIME = 8;

	public BurstEntity(EntityType<? extends BurstEntity> type, Level level) {
		super(type, level);
	}

	@Override
	public void tick() {
		super.tick();
		if (!this.level().isClientSide() && this.tickCount >= LIFETIME) {
			this.discard();
		}
	}
}
