package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** วิชาลูกปราณ: a blue Qi sphere, single target, about 20 blocks of range. */
public class QiBoltEntity extends ProjectileEffect {
	public QiBoltEntity(EntityType<? extends QiBoltEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int chargeTicks() {
		return 5;
	}

	@Override
	protected double speed() {
		return 1.0;
	}

	@Override
	protected int maxFlightTicks() {
		return 20;
	}

	@Override
	protected boolean pierces() {
		return false;
	}
}
