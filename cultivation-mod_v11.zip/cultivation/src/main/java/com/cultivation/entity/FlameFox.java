package com.cultivation.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** จิ้งจอกเพลิง: rare, fast, keeps its distance and throws small fire balls (5 damage). */
public class FlameFox extends BeastEntity {
	private static final float FIRE_DAMAGE = 5.0f;
	private int fireCooldown = 40;

	public FlameFox(EntityType<? extends FlameFox> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createBeastAttributes(24.0, 4.0, 0.42, 24.0);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Player.class, 5.0f, 1.1, 1.4));
	}

	public boolean fireImmune() {
		return true;
	}

	@Override
	public void tick() {
		super.tick();
		if (!(this.level() instanceof ServerLevel level)) {
			return;
		}
		if (fireCooldown > 0) {
			fireCooldown--;
			return;
		}
		LivingEntity target = this.getTarget();
		if (target == null || !target.isAlive()) {
			return;
		}
		double distance = this.distanceToSqr(target);
		if (distance < 9.0 || distance > 196.0 || !this.getSensing().hasLineOfSight(target)) {
			return;
		}
		FireBoltEntity bolt = new FireBoltEntity(ModEntities.FIRE_BOLT, level);
		bolt.setup(this, FIRE_DAMAGE, target.getEyePosition());
		level.addFreshEntity(bolt);
		fireCooldown = 50 + this.random.nextInt(30);
	}
}
