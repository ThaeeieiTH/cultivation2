package com.cultivation.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/** Small fire ball shot by the Flame Fox. Does not hurt other beasts. */
public class FireBoltEntity extends ProjectileEffect {
	public FireBoltEntity(EntityType<? extends FireBoltEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int chargeTicks() {
		return 0;
	}

	@Override
	protected double speed() {
		return 0.6;
	}

	@Override
	protected int maxFlightTicks() {
		return 28;
	}

	@Override
	protected boolean pierces() {
		return false;
	}

	@Override
	protected boolean canHit(LivingEntity target, LivingEntity owner) {
		return super.canHit(target, owner) && !(target instanceof BeastEntity);
	}

	@Override
	protected void onHit(ServerLevel level, LivingEntity target) {
		target.setRemainingFireTicks(60);
		super.onHit(level, target);
	}
}
