package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/** หมูป่าเกราะศิลา: slow charging tank with a stone shell. 30 HP, 6 damage, high resistance. */
public class StoneArmorBoar extends BeastEntity {
	public StoneArmorBoar(EntityType<? extends StoneArmorBoar> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createBeastAttributes(30.0, 6.0, 0.25, 20.0)
			.add(Attributes.ARMOR, 12.0)
			.add(Attributes.KNOCKBACK_RESISTANCE, 0.6);
	}

	@Override
	protected double meleeSpeed() {
		return 1.6;
	}
}
