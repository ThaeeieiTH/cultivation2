package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Effect that simply dissolves after a fixed lifetime. */
public abstract class TimedEffectEntity extends EffectEntity {
	protected TimedEffectEntity(EntityType<? extends TimedEffectEntity> type, Level level) {
		super(type, level);
	}

	protected abstract int lifetime();

	@Override
	public void tick() {
		super.tick();
		if (!this.level().isClientSide() && this.tickCount >= lifetime()) {
			this.discard();
		}
	}
}
