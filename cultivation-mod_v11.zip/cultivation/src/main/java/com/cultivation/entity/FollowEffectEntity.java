package com.cultivation.entity;

import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * An animation that follows one player for a fixed time. It cancels itself safely if the player
 * dies, leaves or is removed. It never touches the player's controls.
 */
public abstract class FollowEffectEntity extends EffectEntity {
	private UUID ownerId;

	protected FollowEffectEntity(EntityType<? extends FollowEffectEntity> type, Level level) {
		super(type, level);
	}

	protected abstract int lifetime();

	protected void onAge(ServerLevel level, ServerPlayer owner, int age) {
	}

	public void bind(ServerPlayer owner) {
		this.ownerId = owner.getUUID();
		follow(owner);
	}

	private void follow(ServerPlayer owner) {
		this.setPos(owner.getX(), owner.getY(), owner.getZ());
		this.setFacing(owner.getYRot(), 0.0f);
	}

	@Override
	public void tick() {
		super.tick();
		if (!(this.level() instanceof ServerLevel level)) {
			return;
		}
		if (ownerId == null) {
			this.discard();
			return;
		}
		Player found = level.getPlayerByUUID(ownerId);
		if (!(found instanceof ServerPlayer owner) || !owner.isAlive() || owner.isRemoved()) {
			this.discard();
			return;
		}
		follow(owner);
		onAge(level, owner, this.tickCount);
		if (this.tickCount >= lifetime()) {
			this.discard();
		}
	}
}
