package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.level.Level;

/** หมาป่าวายุคราม: fast pack hunter. 20 HP, 4 damage. */
public class BlueWindWolf extends BeastEntity {
	public BlueWindWolf(EntityType<? extends BlueWindWolf> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createBeastAttributes(20.0, 4.0, 0.38, 24.0);
	}

	@Override
	protected double meleeSpeed() {
		return 1.3;
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		// Pack behaviour: when one wolf is hurt, the whole pack attacks the attacker.
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this, BlueWindWolf.class).setAlertOthers());
	}
}
