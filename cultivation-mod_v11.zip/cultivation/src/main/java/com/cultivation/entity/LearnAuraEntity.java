package com.cultivation.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** 2.5 second skill-learning animation. Three entity types share this class (blue / azure / gold). */
public class LearnAuraEntity extends FollowEffectEntity {
	public LearnAuraEntity(EntityType<? extends LearnAuraEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int lifetime() {
		return 50;
	}

	@Override
	protected void onAge(ServerLevel level, ServerPlayer owner, int age) {
		if (age == 1) {
			level.playSound(null, owner.blockPosition(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0f, 1.2f);
		} else if (age == 30) {
			level.playSound(null, owner.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.8f, 1.3f);
		}
	}
}
