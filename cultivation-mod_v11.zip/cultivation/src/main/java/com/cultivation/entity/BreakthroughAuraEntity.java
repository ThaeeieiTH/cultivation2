package com.cultivation.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** 4 second breakthrough animation. Three entity types share this class (low / mid / high tier colours). */
public class BreakthroughAuraEntity extends FollowEffectEntity {
	public BreakthroughAuraEntity(EntityType<? extends BreakthroughAuraEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int lifetime() {
		return 80;
	}

	@Override
	protected void onAge(ServerLevel level, ServerPlayer owner, int age) {
		if (age == 1) {
			level.playSound(null, owner.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.0f);
		} else if (age == 25) {
			level.playSound(null, owner.blockPosition(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0f, 0.8f);
		} else if (age == 55) {
			level.playSound(null, owner.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.0f);
		} else if (age == 62) {
			level.playSound(null, owner.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 0.9f, 1.0f);
		}
	}
}
