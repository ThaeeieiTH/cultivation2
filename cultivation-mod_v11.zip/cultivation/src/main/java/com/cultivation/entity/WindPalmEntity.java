package com.cultivation.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** ฝ่ามือวายุปราณ: a short, wide wind wave that damages and knocks back everything in front. */
public class WindPalmEntity extends ProjectileEffect {
	public WindPalmEntity(EntityType<? extends WindPalmEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int chargeTicks() {
		return 2;
	}

	@Override
	protected double speed() {
		return 0.75;
	}

	@Override
	protected int maxFlightTicks() {
		return 6;
	}

	@Override
	protected boolean pierces() {
		return true;
	}

	@Override
	protected double hitInflate() {
		return 1.3;
	}

	@Override
	protected void onHit(ServerLevel level, LivingEntity target) {
		Vec3 flight = this.getDeltaMovement();
		double length = Math.sqrt(flight.x * flight.x + flight.z * flight.z);
		if (length > 1.0E-4) {
			target.push(flight.x / length * 1.1, 0.25, flight.z / length * 1.1);
		}
		super.onHit(level, target);
	}
}
