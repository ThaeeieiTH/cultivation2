package com.cultivation.entity;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * A skill projectile. For the first {@link #chargeTicks()} ticks it stays at the caster's palm
 * and grows (charge animation), then it flies straight, hitting entities along its path on the
 * server. Damage is dealt as the owner so kills credit the owner (experience, training).
 */
public abstract class ProjectileEffect extends EffectEntity {
	private UUID ownerId;
	private Vec3 aim;
	private Vec3 direction = Vec3.ZERO;
	private float damage;
	private boolean launched;
	private int flightTicks;
	private final Set<UUID> alreadyHit = new HashSet<>();

	protected ProjectileEffect(EntityType<? extends ProjectileEffect> type, Level level) {
		super(type, level);
	}

	protected abstract int chargeTicks();

	protected abstract double speed();

	protected abstract int maxFlightTicks();

	protected abstract boolean pierces();

	protected double hitInflate() {
		return 0.5;
	}

	protected boolean canHit(LivingEntity target, LivingEntity owner) {
		return target != owner && !(target instanceof EffectEntity);
	}

	protected void onHit(ServerLevel level, LivingEntity target) {
		spawnBurst(level, target.position().add(0.0, target.getBbHeight() * 0.5, 0.0));
	}

	public void setup(LivingEntity owner, float damage) {
		this.ownerId = owner.getUUID();
		this.damage = damage;
		moveToHand(owner);
	}

	/** Mob owners aim at a target instead of their look direction. */
	public void setup(LivingEntity owner, float damage, Vec3 aimAt) {
		setup(owner, damage);
		this.aim = aimAt;
	}

	private void moveToHand(LivingEntity owner) {
		Vec3 look = owner.getLookAngle();
		Vec3 right = new Vec3(-look.z, 0.0, look.x);
		right = right.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : right.normalize();
		Vec3 pos = owner.getEyePosition().add(look.scale(1.1)).add(right.scale(0.35)).add(0.0, -0.35, 0.0);
		this.setPos(pos.x, pos.y - this.getBbHeight() * 0.5, pos.z);
	}

	private void faceDirection(Vec3 dir) {
		double horizontal = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
		float yaw = (float) (Mth.atan2(-dir.x, dir.z) * 57.29577951308232);
		float pitch = (float) (-(Mth.atan2(dir.y, horizontal) * 57.29577951308232));
		this.setYRot(yaw);
		this.setXRot(pitch);
		this.yRotO = yaw;
		this.xRotO = pitch;
		this.yBodyRot = yaw;
		this.yBodyRotO = yaw;
		this.yHeadRot = yaw;
		this.yHeadRotO = yaw;
	}

	protected DamageSource damageSource(ServerLevel level, LivingEntity owner) {
		if (owner instanceof Player player) {
			return level.damageSources().playerAttack(player);
		}
		return level.damageSources().mobProjectile(this, owner);
	}

	protected void spawnBurst(ServerLevel level, Vec3 at) {
		BurstEntity burst = new BurstEntity(ModEntities.BURST, level);
		burst.setPos(at.x, at.y - 0.25, at.z);
		level.addFreshEntity(burst);
	}

	@Override
	public void tick() {
		super.tick();
		if (!(this.level() instanceof ServerLevel level)) {
			return;
		}
		Entity ownerEntity = ownerId == null ? null : level.getEntity(ownerId);
		if (!(ownerEntity instanceof LivingEntity owner) || !owner.isAlive()) {
			this.discard();
			return;
		}
		if (!launched) {
			moveToHand(owner);
			if (this.tickCount >= chargeTicks()) {
				launched = true;
				Vec3 dir = aim != null ? aim.subtract(this.position()) : owner.getLookAngle();
				direction = dir.lengthSqr() < 1.0E-6 ? owner.getLookAngle() : dir.normalize();
				faceDirection(direction);
				this.setDeltaMovement(direction.scale(speed()));
			}
			return;
		}
		flightTicks++;
		Vec3 next = this.position().add(direction.scale(speed()));
		BlockPos blockPos = BlockPos.containing(next);
		BlockState state = level.getBlockState(blockPos);
		if (!state.getCollisionShape(level, blockPos).isEmpty()) {
			spawnBurst(level, this.position());
			this.discard();
			return;
		}
		this.setPos(next.x, next.y, next.z);
		AABB area = this.getBoundingBox().inflate(hitInflate());
		for (Entity entity : level.getEntities(this, area, e -> e instanceof LivingEntity && e.isAlive())) {
			LivingEntity target = (LivingEntity) entity;
			if (!canHit(target, owner) || !alreadyHit.add(target.getUUID())) {
				continue;
			}
			target.hurtServer(level, damageSource(level, owner), damage);
			onHit(level, target);
			if (!pierces()) {
				this.discard();
				return;
			}
		}
		if (flightTicks >= maxFlightTicks()) {
			spawnBurst(level, this.position());
			this.discard();
		}
	}
}
