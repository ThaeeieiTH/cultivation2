package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Base class of every spirit beast (สัตว์อสูร). Any subclass automatically counts as an
 * experience source when killed by a player (see CultivationActivities).
 */
public abstract class BeastEntity extends PathfinderMob {
	protected BeastEntity(EntityType<? extends BeastEntity> type, Level level) {
		super(type, level);
	}

	protected static AttributeSupplier.Builder createBeastAttributes(double health, double damage, double speed, double followRange) {
		return PathfinderMob.createMobAttributes()
			.add(Attributes.MAX_HEALTH, health)
			.add(Attributes.ATTACK_DAMAGE, damage)
			.add(Attributes.MOVEMENT_SPEED, speed)
			.add(Attributes.FOLLOW_RANGE, followRange);
	}

	protected double meleeSpeed() {
		return 1.2;
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(3, new MeleeAttackGoal(this, meleeSpeed(), true));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
	}
}
