package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Golden ground ring of ปราณสะเทือนปฐพี. */
public class ShockwaveEntity extends TimedEffectEntity {
	public ShockwaveEntity(EntityType<? extends ShockwaveEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected int lifetime() {
		return 12;
	}
}
