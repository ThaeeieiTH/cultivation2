package com.cultivation.skill;

import com.cultivation.CultivationMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

/** Persistence for skill data (separate from the cultivation data attachment). */
public final class SkillAttachments {
	public static final AttachmentType<SkillData> DATA = AttachmentRegistry.create(
		CultivationMod.id("skill_data"),
		builder -> builder
			.initializer(SkillData::empty)
			.persistent(SkillData.CODEC)
			.copyOnDeath()
	);

	private SkillAttachments() {
	}

	public static void init() {
	}
}
