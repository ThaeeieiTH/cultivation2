package com.cultivation.skill;

import com.cultivation.network.CultivationNetworking;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;

/**
 * G key: sit and train Qi. Always server-authoritative. While sitting the player slowly gains
 * proficiency in the selected (learned, not yet mastered) skill, plus basic cultivation. Sitting
 * stops when the player moves, jumps, is hurt, dies, changes dimension, leaves, or presses G again.
 */
public final class MeditationService {
	/** One proficiency point every this many seconds. */
	private static final int SECONDS_PER_POINT = 3;
	private static final double MAX_MOVE_SQ = 0.01;
	private static final double MAX_VERTICAL_MOVE = 0.05;

	private static final class Session {
		final double x;
		final double y;
		final double z;
		final ResourceKey<Level> dimension;
		float health;
		int ticks;

		Session(ServerPlayer player) {
			this.x = player.getX();
			this.y = player.getY();
			this.z = player.getZ();
			this.dimension = player.level().dimension();
			this.health = player.getHealth();
		}
	}

	private static final Map<UUID, Session> ACTIVE = new HashMap<>();

	private MeditationService() {
	}

	private static void say(ServerPlayer player, String text) {
		player.sendSystemMessage(Component.literal(text));
	}

	public static boolean isActive(ServerPlayer player) {
		return ACTIVE.containsKey(player.getUUID());
	}

	public static void register() {
		// No attacking while sitting (checked on the server).
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) ->
			ACTIVE.containsKey(player.getUUID()) ? InteractionResult.FAIL : InteractionResult.PASS);
	}

	public static void toggle(ServerPlayer player) {
		if (isActive(player)) {
			stop(player, "");
		} else {
			start(player);
		}
	}

	private static void start(ServerPlayer player) {
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}
		if (player.isPassenger() || !player.onGround()) {
			say(player, "ต้องอยู่บนพื้นจึงจะนั่งฝึกพลังปราณได้");
			return;
		}
		ACTIVE.put(player.getUUID(), new Session(player));
		player.setShiftKeyDown(true);
		CultivationNetworking.sendMeditation(player, true);
		say(player, "กำลังนั่งฝึกพลังปราณ...");
		SkillData data = SkillStore.get(player);
		SkillType skill = SkillType.byId(data.selected());
		int proficiency = skill == null ? -1 : data.proficiency(skill.id());
		if (skill != null && proficiency >= 0 && proficiency < SkillType.MAX_PROFICIENCY) {
			say(player, "กำลังฝึก " + skill.thaiName() + " " + proficiency + " / " + SkillType.MAX_PROFICIENCY);
		} else {
			say(player, "ฝึกพลังปราณพื้นฐาน (กด V เลือกวิชาที่เรียนแล้วเพื่อฝึกความชำนาญ)");
		}
	}

	public static void stop(ServerPlayer player, String reason) {
		Session session = ACTIVE.remove(player.getUUID());
		if (session == null) {
			return;
		}
		player.setShiftKeyDown(false);
		CultivationNetworking.sendMeditation(player, false);
		say(player, "หยุดนั่งฝึกพลังปราณ" + (reason.isEmpty() ? "" : " (" + reason + ")"));
	}

	/** Disconnect: drop the session without messaging. */
	public static void forget(UUID id) {
		ACTIVE.remove(id);
	}

	public static void tick(MinecraftServer server) {
		if (ACTIVE.isEmpty()) {
			return;
		}
		for (UUID id : new ArrayList<>(ACTIVE.keySet())) {
			Session session = ACTIVE.get(id);
			ServerPlayer player = server.getPlayerList().getPlayer(id);
			if (session == null || player == null) {
				ACTIVE.remove(id);
				continue;
			}
			if (!player.isAlive()) {
				stop(player, "");
				continue;
			}
			if (player.level().dimension() != session.dimension) {
				stop(player, "เปลี่ยนมิติ");
				continue;
			}
			double dx = player.getX() - session.x;
			double dz = player.getZ() - session.z;
			double dy = player.getY() - session.y;
			if (dx * dx + dz * dz > MAX_MOVE_SQ || Math.abs(dy) > MAX_VERTICAL_MOVE || !player.onGround()) {
				stop(player, "ขยับตัว");
				continue;
			}
			if (player.getHealth() < session.health - 0.001f) {
				stop(player, "ถูกโจมตี");
				continue;
			}
			session.health = player.getHealth();
			player.setShiftKeyDown(true);
			session.ticks++;
			if (session.ticks % (20 * SECONDS_PER_POINT) == 0) {
				SkillData data = SkillStore.get(player);
				SkillType skill = SkillType.byId(data.selected());
				// Only the selected skill, only if learned and not yet mastered (train() re-checks).
				if (skill != null) {
					SkillService.train(player, skill, 1);
				}
			}
		}
	}
}
