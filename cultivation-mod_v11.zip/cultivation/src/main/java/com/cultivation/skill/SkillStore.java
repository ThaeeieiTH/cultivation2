package com.cultivation.skill;

import com.cultivation.network.CultivationNetworking;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Server-side access to skill data with once-per-tick client synchronisation. */
public final class SkillStore {
	private static final Set<UUID> DIRTY = new HashSet<>();

	private SkillStore() {
	}

	public static SkillData get(ServerPlayer player) {
		return player.getAttachedOrCreate(SkillAttachments.DATA);
	}

	public static void set(ServerPlayer player, SkillData data) {
		if (data.equals(get(player))) {
			return;
		}
		player.setAttached(SkillAttachments.DATA, data);
		DIRTY.add(player.getUUID());
	}

	public static void flush(MinecraftServer server) {
		if (DIRTY.isEmpty()) {
			return;
		}
		for (UUID id : DIRTY) {
			ServerPlayer player = server.getPlayerList().getPlayer(id);
			if (player != null) {
				CultivationNetworking.sendSkills(player);
			}
		}
		DIRTY.clear();
	}

	public static void forget(UUID id) {
		DIRTY.remove(id);
	}
}
