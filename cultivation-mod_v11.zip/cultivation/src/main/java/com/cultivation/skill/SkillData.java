package com.cultivation.skill;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.HashMap;
import java.util.Map;

/**
 * Per-player skill data. A skill exists in the map only once it has been learned; its value is the
 * proficiency 0-100. The selected skill must be a learned skill, otherwise it is cleared. Casting still needs 100.
 */
public record SkillData(Map<String, Integer> proficiency, String selected) {
	public static final Codec<SkillData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
		Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("proficiency", Map.of()).forGetter(SkillData::proficiency),
		Codec.STRING.optionalFieldOf("selected", "").forGetter(SkillData::selected)
	).apply(instance, SkillData::new));

	public SkillData {
		Map<String, Integer> cleaned = new HashMap<>();
		for (Map.Entry<String, Integer> entry : proficiency.entrySet()) {
			if (SkillType.byId(entry.getKey()) != null && entry.getValue() != null) {
				cleaned.put(entry.getKey(), Math.clamp(entry.getValue(), 0, SkillType.MAX_PROFICIENCY));
			}
		}
		proficiency = Map.copyOf(cleaned);
		if (selected == null || !proficiency.containsKey(selected)) {
			selected = "";
		}
	}

	public static SkillData empty() {
		return new SkillData(Map.of(), "");
	}

	public boolean isLearned(String id) {
		return proficiency.containsKey(id);
	}

	/** Proficiency of a skill, or -1 when it has not been learned. */
	public int proficiency(String id) {
		return proficiency.getOrDefault(id, -1);
	}

	public boolean isMastered(String id) {
		return proficiency(id) >= SkillType.MAX_PROFICIENCY;
	}

	public SkillData learn(String id) {
		Map<String, Integer> copy = new HashMap<>(proficiency);
		copy.putIfAbsent(id, 0);
		return new SkillData(copy, selected);
	}

	public SkillData withProficiency(String id, int value) {
		if (!isLearned(id)) {
			return this;
		}
		Map<String, Integer> copy = new HashMap<>(proficiency);
		copy.put(id, value);
		return new SkillData(copy, selected);
	}

	public SkillData withSelected(String id) {
		return new SkillData(proficiency, id);
	}
}
