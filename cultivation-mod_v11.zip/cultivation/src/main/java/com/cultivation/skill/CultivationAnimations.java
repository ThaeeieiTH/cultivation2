package com.cultivation.skill;

import com.cultivation.data.CultivationStore;
import com.cultivation.entity.BreakthroughAuraEntity;
import com.cultivation.entity.LearnAuraEntity;
import com.cultivation.entity.ModEntities;
import com.cultivation.progression.CultivationRules;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;

/**
 * Plays the breakthrough and skill-learning animations. Called only after the server has
 * confirmed success, so failed attempts never show an animation. The effect entities are tracked
 * by nearby players, so they see it too; the big centre-screen title is shown to the player only.
 */
public final class CultivationAnimations {
	private CultivationAnimations() {
	}

	private static void title(ServerPlayer player, String title, Component subtitle, ChatFormatting color) {
		player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 50, 20));
		player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
		player.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title).withStyle(color, ChatFormatting.BOLD)));
	}

	/** Called after a successful M press. {@code realmChanged} is true for a full realm breakthrough. */
	public static void playBreakthrough(ServerPlayer player, boolean realmChanged) {
		ServerLevel level = (ServerLevel) player.level();
		int realm = CultivationStore.get(player).realm();
		EntityType<BreakthroughAuraEntity> type = realm >= 6 ? ModEntities.AURA_HIGH
			: realm >= 3 ? ModEntities.AURA_MID : ModEntities.AURA_LOW;
		BreakthroughAuraEntity aura = new BreakthroughAuraEntity(type, level);
		aura.bind(player);
		level.addFreshEntity(aura);
		int stage = CultivationStore.get(player).stage();
		Component name = Component.literal(CultivationRules.displayName(realm, stage)).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD);
		title(player, realmChanged ? "ทะลวงขั้นสำเร็จ!" : "เลื่อนขั้นสำเร็จ!", name, ChatFormatting.GOLD);
	}

	/** Called after a skill was learned for the first time. */
	public static void playLearn(ServerPlayer player, SkillType skill) {
		ServerLevel level = (ServerLevel) player.level();
		EntityType<LearnAuraEntity> type = switch (skill) {
			case AZURE_SWORD -> ModEntities.LEARN_AZURE;
			case EARTH_SHOCK -> ModEntities.LEARN_GOLD;
			default -> ModEntities.LEARN_BLUE;
		};
		LearnAuraEntity aura = new LearnAuraEntity(type, level);
		aura.bind(player);
		level.addFreshEntity(aura);
		Component name = Component.literal(skill.thaiName()).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD);
		title(player, "เรียนรู้วิชาใหม่สำเร็จ!", name, ChatFormatting.GOLD);
	}
}
