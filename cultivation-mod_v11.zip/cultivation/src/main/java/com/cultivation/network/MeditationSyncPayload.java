package com.cultivation.network;

import com.cultivation.CultivationMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: whether the player is currently sitting and training (for the HUD). */
public record MeditationSyncPayload(boolean active) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<MeditationSyncPayload> TYPE =
		new CustomPacketPayload.Type<>(CultivationMod.id("meditation_sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, MeditationSyncPayload> CODEC = StreamCodec.composite(
		ByteBufCodecs.BOOL, MeditationSyncPayload::active,
		MeditationSyncPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
