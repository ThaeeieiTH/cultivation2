package com.cultivation.network;

import com.cultivation.CultivationMod;
import com.cultivation.skill.SkillData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client snapshot of the player's skills (shown in the N screen and the HUD skill name). */
public record SkillSyncPayload(String selected, List<String> ids, List<Integer> values) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<SkillSyncPayload> TYPE =
		new CustomPacketPayload.Type<>(CultivationMod.id("skill_sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, SkillSyncPayload> CODEC = StreamCodec.composite(
		ByteBufCodecs.STRING_UTF8, SkillSyncPayload::selected,
		ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()), SkillSyncPayload::ids,
		ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list()), SkillSyncPayload::values,
		SkillSyncPayload::new
	);

	public static SkillSyncPayload from(SkillData data) {
		List<String> ids = new ArrayList<>();
		List<Integer> values = new ArrayList<>();
		for (Map.Entry<String, Integer> entry : data.proficiency().entrySet()) {
			ids.add(entry.getKey());
			values.add(entry.getValue());
		}
		return new SkillSyncPayload(data.selected(), ids, values);
	}

	public int proficiency(String id) {
		int index = ids.indexOf(id);
		return index < 0 ? -1 : values.get(index);
	}

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
