package com.cultivation.client.model;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Breakthrough animation (80 ticks): a ring forms under the feet, Qi motes spin around the body,
 * rings rise and shrink while everything converges on the core (ticks 22-60), then a shockwave
 * of rings and spikes bursts outwards (ticks 60-76).
 */
public class AuraModel extends GlowModel {
	private final ModelPart ringGround;
	private final ModelPart ringMid1;
	private final ModelPart ringMid2;
	private final ModelPart motes;
	private final ModelPart core;
	private final ModelPart blast;

	public AuraModel(ModelPart root) {
		super(root);
		this.ringGround = root.getChild("ring_ground");
		this.ringMid1 = root.getChild("ring_mid1");
		this.ringMid2 = root.getChild("ring_mid2");
		this.motes = root.getChild("motes");
		this.core = root.getChild("core");
		this.blast = root.getChild("blast");
	}

	private static CubeListBuilder ring(float r) {
		return RingModel.ringBoxes(r, 1.6f, 1.0f);
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("ring_ground", ring(14), PartPose.offset(0, 23.5f, 0));
		root.addOrReplaceChild("ring_mid1", ring(12), PartPose.offset(0, 22, 0));
		root.addOrReplaceChild("ring_mid2", ring(9), PartPose.offset(0, 22, 0));
		PartDefinition motes = root.addOrReplaceChild("motes", CubeListBuilder.create(), PartPose.offset(0, 12, 0));
		for (int k = 0; k < 8; k++) {
			double a = k * Math.PI / 4.0;
			motes.addOrReplaceChild("mote" + k, CubeListBuilder.create().texOffs(0, 8).addBox(-1, -1, -1, 2, 2, 2),
				PartPose.offset((float) (16.0 * Math.cos(a)), (k % 2 == 0) ? -5.0f : 5.0f, (float) (16.0 * Math.sin(a))));
		}
		root.addOrReplaceChild("core", CubeListBuilder.create().texOffs(0, 0).addBox(-3, -3, -3, 6, 6, 6), PartPose.offset(0, 12, 0));
		root.addOrReplaceChild("blast", RingModel.ringBoxes(8, 1.6f, 1.0f).texOffs(0, 16)
			.addBox(-9, -0.6f, -0.6f, 18, 1.2f, 1.2f)
			.addBox(-0.6f, -9, -0.6f, 1.2f, 18, 1.2f)
			.addBox(-0.6f, -0.6f, -9, 1.2f, 1.2f, 18), PartPose.offset(0, 12, 0));
		return LayerDefinition.create(mesh, 64, 64);
	}

	private static void flat(ModelPart part, float s) {
		part.xScale = s;
		part.zScale = s;
		part.yScale = 1.0f;
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float a = state.ageInTicks;
		boolean converging = a < 60.0f;
		float appear = Mth.clamp(a / 18.0f, 0.0f, 1.0f);
		float conv = Mth.clamp((a - 22.0f) / 38.0f, 0.0f, 1.0f);
		float blastT = Mth.clamp((a - 60.0f) / 16.0f, 0.0f, 1.0f);
		float spin = a * 0.18f;

		ringGround.yRot = spin;
		flat(ringGround, converging ? appear : appear * (1.0f + blastT * 4.5f));

		float rise = Mth.clamp((a - 14.0f) / 40.0f, 0.0f, 1.0f) * 32.0f;
		float midScale = converging ? (1.0f - conv * 0.65f) * appear : 0.35f * (1.0f + blastT * 8.0f);
		ringMid1.y = 22.0f - rise;
		ringMid1.yRot = -spin * 1.3f;
		flat(ringMid1, midScale);
		ringMid2.y = 22.0f - rise * 0.6f;
		ringMid2.yRot = spin * 1.1f;
		flat(ringMid2, midScale);

		motes.yRot = spin * 1.5f;
		scale(motes, converging ? appear * (1.0f - conv * 0.95f) : 0.0f);

		float coreScale = converging
			? 0.2f + conv * 1.5f + 0.1f * Mth.sin(a * 0.8f)
			: Math.max(0.0f, 1.7f * (1.0f - blastT * 1.5f));
		scale(core, coreScale);

		float blastScale = converging ? 0.0f : (blastT < 1.0f ? blastT * 7.0f : 7.0f * (1.0f - Mth.clamp((a - 76.0f) / 4.0f, 0.0f, 1.0f)));
		scale(blast, blastScale);
		blast.yRot = a * 0.3f;
	}
}
