package com.cultivation.client.model;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Impact burst: a core, a ring and radiating spikes that expand and dissolve. */
public class BurstModel extends GlowModel {
	private final ModelPart core;
	private final ModelPart ring;
	private final ModelPart spikes;
	private final ModelPart diagonals;

	public BurstModel(ModelPart root) {
		super(root);
		this.core = root.getChild("core");
		this.ring = root.getChild("ring");
		this.spikes = root.getChild("spikes");
		this.diagonals = root.getChild("diagonals");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("core", CubeListBuilder.create().texOffs(0, 0).addBox(-2, -2, -2, 4, 4, 4), PartPose.offset(0, 20, 0));
		root.addOrReplaceChild("ring", CubeListBuilder.create().texOffs(0, 16)
			.addBox(-7, -0.5f, -7, 14, 1, 1.5f)
			.addBox(-7, -0.5f, 5.5f, 14, 1, 1.5f)
			.addBox(-7, -0.5f, -5.5f, 1.5f, 1, 11)
			.addBox(5.5f, -0.5f, -5.5f, 1.5f, 1, 11), PartPose.offset(0, 20, 0));
		CubeListBuilder bars = CubeListBuilder.create().texOffs(0, 32)
			.addBox(-9, -0.6f, -0.6f, 18, 1.2f, 1.2f)
			.addBox(-0.6f, -9, -0.6f, 1.2f, 18, 1.2f)
			.addBox(-0.6f, -0.6f, -9, 1.2f, 1.2f, 18);
		root.addOrReplaceChild("spikes", bars, PartPose.offset(0, 20, 0));
		root.addOrReplaceChild("diagonals", CubeListBuilder.create().texOffs(0, 40)
			.addBox(-6, -0.5f, -0.5f, 12, 1, 1)
			.addBox(-0.5f, -6, -0.5f, 1, 12, 1), PartPose.offsetAndRotation(0, 20, 0, 0, 0.7854f, 0.7854f));
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float age = state.ageInTicks;
		float s = 0.35f + age * 0.22f;
		float fade = Mth.clamp(1.0f - age / 9.0f, 0.15f, 1.0f);
		scale(core, s * 0.8f * fade + 0.2f);
		scale(ring, s);
		scale(spikes, s * 0.9f);
		scale(diagonals, s);
		spikes.yRot = age * 0.35f;
		diagonals.yRot = 0.7854f - age * 0.3f;
		ring.xRot = age * 0.1f;
	}
}
