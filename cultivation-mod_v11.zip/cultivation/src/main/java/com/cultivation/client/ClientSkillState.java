package com.cultivation.client;

import com.cultivation.network.SkillSyncPayload;
import java.util.List;

/** Latest skill snapshot received from the server. */
public final class ClientSkillState {
	private static volatile SkillSyncPayload current = new SkillSyncPayload("", List.of(), List.of());

	private ClientSkillState() {
	}

	public static SkillSyncPayload get() {
		return current;
	}

	public static void set(SkillSyncPayload payload) {
		current = payload;
	}

	public static void clear() {
		current = new SkillSyncPayload("", List.of(), List.of());
	}
}
