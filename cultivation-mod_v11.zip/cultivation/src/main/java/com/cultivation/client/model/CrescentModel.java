package com.cultivation.client.model;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Crescent-moon sword wave: a curved blade of thin segments plus a trailing echo arc. */
public class CrescentModel extends GlowModel {
	private final ModelPart wave;

	public CrescentModel(ModelPart root) {
		super(root);
		this.wave = root.getChild("wave");
	}

	private static void arc(PartDefinition parent, String prefix, float radius, float zShift, float heightScale, int texU) {
		for (int k = -5; k <= 5; k++) {
			float a = k * 0.22f;
			float x = radius * Mth.sin(a);
			float z = radius - radius * Mth.cos(a) + zShift;
			float height = Math.max(2.0f, 9.0f * heightScale * (1.0f - Math.abs(k) * 0.12f));
			float thickness = Math.max(0.8f, 3.2f - Math.abs(k) * 0.45f);
			parent.addOrReplaceChild(prefix + (k + 5),
				CubeListBuilder.create().texOffs(texU, 0).addBox(-2.2f, -height / 2.0f, -thickness / 2.0f, 4.4f, height, thickness),
				PartPose.offsetAndRotation(x, 0, z, 0, -a, 0));
		}
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition wave = root.addOrReplaceChild("wave", CubeListBuilder.create(), PartPose.offset(0, 20, 0));
		arc(wave, "blade", 15.0f, 0.0f, 1.0f, 0);
		arc(wave, "echo", 12.0f, 8.0f, 0.65f, 20);
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float t = Mth.clamp(state.ageInTicks / 4.0f, 0.0f, 1.0f);
		float pulse = 1.0f + 0.05f * Mth.sin(state.ageInTicks * 1.2f);
		scale(wave, (0.4f + 0.6f * t) * pulse);
		wave.yRot = (1.0f - t) * 1.1f;
		wave.zRot = -0.35f;
	}
}
