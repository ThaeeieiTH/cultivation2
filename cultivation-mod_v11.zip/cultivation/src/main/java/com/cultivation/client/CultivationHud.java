package com.cultivation.client;

import com.cultivation.CultivationMod;
import com.cultivation.network.CultivationSyncPayload;
import com.cultivation.network.SkillSyncPayload;
import com.cultivation.progression.CultivationRules;
import com.cultivation.skill.SkillType;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Xianxia-style HUD (bottom-left, above the hotbar line): dark green-black panel with gold trim,
 * mod title, player level, realm and sub-stage, red health bar, teal-blue Qi bar and gold cultivation
 * EXP bar, each with a small icon. Everything is read from the real synced / client player data.
 */
public final class CultivationHud {
	private static final int X = 6;
	private static final int WIDTH = 146;
	private static final int BAR_HEIGHT = 10;

	private static final int PANEL_BG = 0xE60A1510;
	private static final int GOLD = 0xFFD4AF37;
	private static final int GOLD_DARK = 0xFF6B5B2A;
	private static final int TITLE_COLOR = 0xFFFFD75E;
	private static final int REALM_COLOR = 0xFF9FF0D0;
	private static final int LEVEL_COLOR = 0xFFEFEFEF;
	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int SKILL_COLOR = 0xFF9FE8FF;
	private static final int HINT_COLOR = 0xFF7CFF7C;

	private static final String[] HEART = {".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};
	private static final String[] DROP = {"...X...", "..XXX..", ".XXXXX.", "XXXXXXX", "XXXXXXX", ".XXXXX."};
	private static final String[] LOTUS = {"...X...", "..XXX..", ".XXXXX.", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};

	private CultivationHud() {
	}

	public static void register() {
		HudElementRegistry.addLast(CultivationMod.id("cultivation_hud"), CultivationHud::render);
	}

	private static String number(long value) {
		return String.format(Locale.ROOT, "%,d", value);
	}

	private static void roundFill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color) {
		g.fill(x1 + 1, y1, x2 - 1, y2, color);
		g.fill(x1, y1 + 1, x2, y2 - 1, color);
	}

	private static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int border) {
		roundFill(g, x, y, x + w, y + h, border);
		roundFill(g, x + 1, y + 1, x + w - 1, y + h - 1, PANEL_BG);
		g.outline(x + 2, y + 2, w - 4, h - 4, GOLD_DARK);
		// gold corner studs
		g.fill(x + 1, y + 1, x + 4, y + 2, border);
		g.fill(x + 1, y + 1, x + 2, y + 4, border);
		g.fill(x + w - 4, y + h - 2, x + w - 1, y + h - 1, border);
		g.fill(x + w - 2, y + h - 4, x + w - 1, y + h - 1, border);
	}

	private static void icon(GuiGraphicsExtractor g, int x, int y, String[] rows, int color) {
		for (int j = 0; j < rows.length; j++) {
			for (int i = 0; i < rows[j].length(); i++) {
				if (rows[j].charAt(i) == 'X') {
					g.fill(x + i, y + j, x + i + 1, y + j + 1, color);
				}
			}
		}
	}

	private static void bar(GuiGraphicsExtractor g, int x, int y, int w, double ratio, int top, int bottom, int back) {
		roundFill(g, x, y, x + w, y + BAR_HEIGHT, 0xFF000000);
		roundFill(g, x + 1, y + 1, x + w - 1, y + BAR_HEIGHT - 1, back);
		int filled = (int) Math.round((w - 2) * Math.clamp(ratio, 0.0, 1.0));
		if (filled > 0) {
			int mid = y + 1 + (BAR_HEIGHT - 2) / 2;
			g.fill(x + 1, y + 1, x + 1 + filled, mid, top);
			g.fill(x + 1, mid, x + 1 + filled, y + BAR_HEIGHT - 1, bottom);
		}
	}

	private static void render(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
		CultivationSyncPayload state = ClientCultivationState.get();
		Minecraft mc = Minecraft.getInstance();
		if (state == null || mc.player == null) {
			return;
		}
		Font font = mc.font;
		boolean max = state.isMaxState();
		boolean ready = state.isReadyToAdvance();
		boolean meditating = ClientMeditationState.isActive();
		long since = System.currentTimeMillis() - ClientCultivationState.levelUpAt();
		boolean flash = since >= 0 && since < 2500;
		SkillType selected = SkillType.byId(ClientSkillState.get().selected());

		int height = 4 + 11 + 11 + 36 + 11 + 4 + (meditating ? 22 : 0) + (ready ? 11 : 0) + (flash ? 11 : 0);
		int x = X;
		int y = mc.getWindow().getGuiScaledHeight() - 26 - height;
		int border = flash && (since / 150) % 2 == 0 ? 0xFFFFF0A0 : GOLD;
		panel(g, x, y, WIDTH, height, border);

		int cx = x + 5;
		int cy = y + 5;
		g.text(font, "【ตำนานเซียน】", cx, cy, TITLE_COLOR, true);
		String level = "เลเวล " + mc.player.experienceLevel;
		g.text(font, level, x + WIDTH - 5 - font.width(level), cy, LEVEL_COLOR, true);
		cy += 11;
		g.text(font, CultivationRules.displayName(state.realm(), state.stage()), cx, cy, REALM_COLOR, true);
		cy += 11;

		int barX = cx + 10;
		int barW = WIDTH - 10 - 10;

		int health = (int) Math.ceil(mc.player.getHealth());
		int maxHealth = Math.max(1, (int) Math.ceil(mc.player.getMaxHealth()));
		icon(g, cx, cy + 2, HEART, 0xFFFF5A5A);
		bar(g, barX, cy, barW, (double) health / maxHealth, 0xFFE04848, 0xFF9E1B1B, 0xFF2A0A0A);
		g.text(font, "เลือด " + health + " / " + maxHealth, barX + 3, cy + 1, TEXT_COLOR, true);
		cy += 12;

		icon(g, cx, cy + 2, DROP, 0xFF48C8F0);
		double qiRatio = state.maxQi() <= 0 ? 0.0 : (double) state.qi() / state.maxQi();
		bar(g, barX, cy, barW, qiRatio, 0xFF48E0D0, 0xFF2B7FD8, 0xFF081A2A);
		g.text(font, "ปราณ " + number(state.qi()) + " / " + number(state.maxQi()), barX + 3, cy + 1, TEXT_COLOR, true);
		cy += 12;

		icon(g, cx, cy + 2, LOTUS, 0xFFFFD75E);
		double expRatio = max ? 1.0 : (state.required() <= 0L ? 0.0 : (double) state.experience() / state.required());
		bar(g, barX, cy, barW, expRatio, 0xFFFFE680, 0xFFD4A017, 0xFF2A2208);
		String exp = max ? "EXP สูงสุด (MAX)" : "EXP " + number(state.experience()) + " / " + number(state.required());
		g.text(font, exp, barX + 3, cy + 1, TEXT_COLOR, true);
		cy += 12;

		g.text(font, "วิชา: " + (selected == null ? "-" : selected.thaiName()), cx, cy, SKILL_COLOR, true);
		cy += 11;

		if (meditating) {
			g.text(font, "กำลังนั่งฝึกพลังปราณ", cx, cy, HINT_COLOR, true);
			cy += 11;
			SkillSyncPayload skills = ClientSkillState.get();
			int proficiency = selected == null ? -1 : skills.proficiency(selected.id());
			String line = (selected != null && proficiency >= 0 && proficiency < SkillType.MAX_PROFICIENCY)
				? selected.thaiName() + " " + proficiency + " / " + SkillType.MAX_PROFICIENCY
				: "ฝึกพลังปราณพื้นฐาน";
			g.text(font, line, cx, cy, SKILL_COLOR, true);
			cy += 11;
		}
		if (ready) {
			g.text(font, state.stage() >= CultivationRules.LAST_STAGE ? "พร้อมทะลวง: กด M" : "พร้อมเลื่อนขั้น: กด M", cx, cy, HINT_COLOR, true);
			cy += 11;
		}
		if (flash) {
			g.text(font, "【เลื่อนขั้นสำเร็จ】", cx, cy, 0xFFFFF0A0, true);
		}
	}
}
