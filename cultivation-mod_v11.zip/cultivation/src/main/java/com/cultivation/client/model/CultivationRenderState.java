package com.cultivation.client.model;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class CultivationRenderState extends LivingEntityRenderState {
	/** Melee swing progress 0..1, copied from the entity so the model can animate the bite. */
	public float attackTime;
}
