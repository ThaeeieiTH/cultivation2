package com.cultivation.client.model;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Golden ground shockwave: two expanding rings with debris that lifts off the ground. */
public class RingModel extends GlowModel {
	private final ModelPart ring;
	private final ModelPart ring2;
	private final ModelPart debris;

	public RingModel(ModelPart root) {
		super(root);
		this.ring = root.getChild("ring");
		this.ring2 = root.getChild("ring2");
		this.debris = root.getChild("debris");
	}

	static CubeListBuilder ringBoxes(float r, float thick, float height) {
		return CubeListBuilder.create().texOffs(0, 0)
			.addBox(-r, -height / 2.0f, -r, 2 * r, height, thick)
			.addBox(-r, -height / 2.0f, r - thick, 2 * r, height, thick)
			.addBox(-r, -height / 2.0f, -r + thick, thick, height, 2 * r - 2 * thick)
			.addBox(r - thick, -height / 2.0f, -r + thick, thick, height, 2 * r - 2 * thick);
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("ring", ringBoxes(7, 1.8f, 2.0f), PartPose.offset(0, 23.5f, 0));
		root.addOrReplaceChild("ring2", ringBoxes(4.5f, 1.5f, 1.6f), PartPose.offset(0, 23.4f, 0));
		PartDefinition debris = root.addOrReplaceChild("debris", CubeListBuilder.create(), PartPose.offset(0, 23, 0));
		for (int k = 0; k < 10; k++) {
			double a = k * Math.PI * 2.0 / 10.0;
			debris.addOrReplaceChild("d" + k, CubeListBuilder.create().texOffs(0, 8).addBox(-1, -1.5f, -1, 2, 3, 2),
				PartPose.offset((float) (6.0 * Math.cos(a)), (k % 3) * -1.2f, (float) (6.0 * Math.sin(a))));
		}
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float p = Mth.clamp(state.ageInTicks / 10.0f, 0.0f, 1.0f);
		float r = 0.4f + p * 8.0f;
		ring.xScale = r;
		ring.zScale = r;
		ring.yScale = 1.3f * (1.0f - p * 0.6f);
		float r2 = 0.2f + p * 6.0f;
		ring2.xScale = r2;
		ring2.zScale = r2;
		ring2.yScale = 1.0f - p * 0.5f;
		debris.xScale = r * 0.95f;
		debris.zScale = r * 0.95f;
		debris.yScale = 1.0f;
		debris.y = 23.0f - Mth.sin(p * 3.1416f) * 6.0f;
		debris.yRot = state.ageInTicks * 0.1f;
	}
}
