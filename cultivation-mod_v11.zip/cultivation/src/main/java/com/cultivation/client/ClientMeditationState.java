package com.cultivation.client;

public final class ClientMeditationState {
	private static volatile boolean active;

	private ClientMeditationState() {
	}

	public static boolean isActive() {
		return active;
	}

	public static void set(boolean value) {
		active = value;
	}
}
