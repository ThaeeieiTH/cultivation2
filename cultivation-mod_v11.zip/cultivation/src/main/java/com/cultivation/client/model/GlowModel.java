package com.cultivation.client.model;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;

/** Base class of the mod's own skill-effect models. */
public abstract class GlowModel extends EntityModel<CultivationRenderState> {
	protected GlowModel(ModelPart root) {
		super(root);
	}

	protected static void scale(ModelPart part, float s) {
		part.xScale = s;
		part.yScale = s;
		part.zScale = s;
	}
}
