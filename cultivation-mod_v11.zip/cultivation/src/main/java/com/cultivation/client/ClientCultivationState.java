package com.cultivation.client;

import com.cultivation.network.CultivationSyncPayload;

/** Latest cultivation snapshot received from the server. */
public final class ClientCultivationState {
	private static volatile CultivationSyncPayload current;
	private static volatile long levelUpAt;

	private ClientCultivationState() {
	}

	public static CultivationSyncPayload get() {
		return current;
	}

	/** Time (ms) of the last realm / sub-stage increase, for the HUD level-up flash. */
	public static long levelUpAt() {
		return levelUpAt;
	}

	public static void set(CultivationSyncPayload payload) {
		CultivationSyncPayload old = current;
		if (old != null && (payload.realm() > old.realm()
			|| (payload.realm() == old.realm() && payload.stage() > old.stage()))) {
			levelUpAt = System.currentTimeMillis();
		}
		current = payload;
	}

	public static void clear() {
		current = null;
		levelUpAt = 0L;
	}
}
