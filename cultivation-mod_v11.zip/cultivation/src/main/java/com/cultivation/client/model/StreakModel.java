package com.cultivation.client.model;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Cross-shaped wind streak that trails behind the dashing player and thins out. */
public class StreakModel extends GlowModel {
	private final ModelPart streak;

	public StreakModel(ModelPart root) {
		super(root);
		this.streak = root.getChild("streak");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("streak", CubeListBuilder.create().texOffs(0, 0)
			.addBox(-6, -0.5f, 0, 12, 1, 26)
			.addBox(-0.5f, -6, 0, 1, 12, 26)
			.addBox(-1.5f, -1.5f, 0, 3, 3, 20)
			.addBox(-3.5f, -0.4f, 4, 7, 0.8f, 18), PartPose.offset(0, 12, 0));
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float a = state.ageInTicks;
		streak.zScale = Mth.clamp(1.0f - a / 10.0f, 0.05f, 1.0f);
		float w = 1.0f + a * 0.06f;
		streak.xScale = w;
		streak.yScale = w;
	}
}
