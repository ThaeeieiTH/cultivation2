package com.cultivation.client.render;

import com.cultivation.CultivationMod;
import com.cultivation.client.model.CultivationRenderState;
import com.cultivation.client.model.GlowModel;
import com.cultivation.entity.EffectEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;

/** Renders a skill effect with its own model and texture, always at full brightness. */
public class EffectRenderer<T extends EffectEntity> extends MobRenderer<T, CultivationRenderState, GlowModel> {
	private final Identifier texture;

	public EffectRenderer(EntityRendererProvider.Context context, GlowModel model, String textureName) {
		super(context, model, 0.0f);
		this.texture = CultivationMod.id("textures/entity/" + textureName + ".png");
	}

	@Override
	public CultivationRenderState createRenderState() {
		return new CultivationRenderState();
	}

	@Override
	public Identifier getTextureLocation(CultivationRenderState state) {
		return texture;
	}

	protected int getBlockLightLevel(T entity, BlockPos pos) {
		return 15;
	}
}
