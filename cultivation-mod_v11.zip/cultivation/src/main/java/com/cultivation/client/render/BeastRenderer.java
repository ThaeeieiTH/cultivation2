package com.cultivation.client.render;

import com.cultivation.CultivationMod;
import com.cultivation.client.model.BeastModel;
import com.cultivation.client.model.CultivationRenderState;
import com.cultivation.entity.BeastEntity;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

/** Renders a spirit beast with its own model layer and texture. */
public class BeastRenderer<T extends BeastEntity> extends MobRenderer<T, CultivationRenderState, BeastModel> {
	private final Identifier texture;

	public BeastRenderer(EntityRendererProvider.Context context, ModelLayerLocation layer, String textureName, float shadow) {
		super(context, new BeastModel(context.bakeLayer(layer)), shadow);
		this.texture = CultivationMod.id("textures/entity/" + textureName + ".png");
	}

	@Override
	public CultivationRenderState createRenderState() {
		return new CultivationRenderState();
	}

	@Override
	public void extractRenderState(T entity, CultivationRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.attackTime = entity.getAttackAnim(partialTick);
	}

	@Override
	public Identifier getTextureLocation(CultivationRenderState state) {
		return texture;
	}
}
