package com.cultivation.client.model;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Hand-built blocky quadruped model shared by the three spirit beasts. Each beast has its own
 * layer definition (own proportions, ears, armour plates, flame tail) and its own texture.
 */
public class BeastModel extends EntityModel<CultivationRenderState> {
	private static final float DEG = 0.017453292f;

	private final ModelPart head;
	private final ModelPart tail;
	private final ModelPart legFl;
	private final ModelPart legFr;
	private final ModelPart legBl;
	private final ModelPart legBr;

	public BeastModel(ModelPart root) {
		super(root);
		this.head = root.getChild("head");
		this.tail = root.getChild("tail");
		this.legFl = root.getChild("leg_fl");
		this.legFr = root.getChild("leg_fr");
		this.legBl = root.getChild("leg_bl");
		this.legBr = root.getChild("leg_br");
	}

	private static void legs(PartDefinition root, float w, float h, int u, int v, float y, float x, float zFront, float zBack) {
		CubeListBuilder leg = CubeListBuilder.create().texOffs(u, v).addBox(-w / 2.0f, 0, -w / 2.0f, w, h, w);
		root.addOrReplaceChild("leg_fl", leg, PartPose.offset(-x, y, zFront));
		root.addOrReplaceChild("leg_fr", leg, PartPose.offset(x, y, zFront));
		root.addOrReplaceChild("leg_bl", leg, PartPose.offset(-x, y, zBack));
		root.addOrReplaceChild("leg_br", leg, PartPose.offset(x, y, zBack));
	}

	/** หมาป่าวายุคราม: lean wolf with pointed ears and a raised tail. */
	public static LayerDefinition wolfLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-3.5f, -3.5f, -7, 7, 7, 14), PartPose.offset(0, 13, 0));
		root.addOrReplaceChild("head", CubeListBuilder.create()
			.texOffs(0, 0).addBox(-3, -3, -6, 6, 6, 6)
			.texOffs(24, 0).addBox(-1.5f, 0, -9, 3, 3, 3)
			.texOffs(36, 0).addBox(-3.5f, -5, -1.5f, 2, 2, 1)
			.addBox(1.5f, -5, -1.5f, 2, 2, 1), PartPose.offset(0, 11, -7));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(16, 38).addBox(-1.5f, 0, 0, 3, 3, 8),
			PartPose.offsetAndRotation(0, 10.5f, 7, -0.4f, 0, 0));
		legs(root, 3, 8, 0, 38, 16, 2.5f, -5, 5);
		return LayerDefinition.create(mesh, 64, 64);
	}

	/** หมูป่าเกราะศิลา: heavy boar with tusks, a stone shell on its back and shoulder plates. */
	public static LayerDefinition boarLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-5, -5, -8, 10, 10, 16), PartPose.offset(0, 12.5f, 0));
		root.addOrReplaceChild("plates", CubeListBuilder.create().texOffs(20, 44)
			.addBox(-4, -7.5f, -6, 8, 2.5f, 5)
			.addBox(-4, -7.5f, 0, 8, 2.5f, 6)
			.addBox(-6.8f, -4, -7, 2, 6, 6)
			.addBox(4.8f, -4, -7, 2, 6, 6), PartPose.offset(0, 12.5f, 0));
		root.addOrReplaceChild("head", CubeListBuilder.create()
			.texOffs(0, 0).addBox(-4, -4, -7, 8, 8, 7)
			.texOffs(30, 6).addBox(-2, 0.5f, -9, 4, 3, 2)
			.texOffs(30, 0).addBox(-4.8f, 1, -7, 1.2f, 3, 1.2f)
			.addBox(3.6f, 1, -7, 1.2f, 3, 1.2f), PartPose.offset(0, 14, -8));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 60).addBox(-0.75f, 0, 0, 1.5f, 1.5f, 3),
			PartPose.offset(0, 9, 8));
		legs(root, 4, 7, 0, 44, 17, 3.5f, -6, 6);
		return LayerDefinition.create(mesh, 64, 64);
	}

	/** จิ้งจอกเพลิง: slim fox with big ears and a long tail ending in a glowing flame. */
	public static LayerDefinition foxLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-3, -3, -6, 6, 6, 12), PartPose.offset(0, 14, 0));
		root.addOrReplaceChild("head", CubeListBuilder.create()
			.texOffs(0, 0).addBox(-3, -3, -5, 6, 5, 5)
			.texOffs(22, 0).addBox(-1.5f, 0, -8, 3, 2, 3)
			.texOffs(34, 0).addBox(-3, -6, -2, 2, 3, 1)
			.addBox(1, -6, -2, 2, 3, 1), PartPose.offset(0, 12, -6.5f));
		root.addOrReplaceChild("tail", CubeListBuilder.create()
			.texOffs(12, 36).addBox(-2.5f, -2.5f, 0, 5, 5, 12)
			.texOffs(48, 0).addBox(-1.5f, -1.5f, 12, 3, 3, 4), PartPose.offsetAndRotation(0, 13, 6, -0.3f, 0, 0));
		legs(root, 2, 7, 0, 36, 17, 2, -4.5f, 4.5f);
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float swing = state.walkAnimationPos;
		float amount = state.walkAnimationSpeed;
		float a = Mth.cos(swing * 0.6662f) * 1.4f * amount;
		float b = Mth.cos(swing * 0.6662f + Mth.PI) * 1.4f * amount;
		legFl.xRot = a;
		legBr.xRot = a;
		legFr.xRot = b;
		legBl.xRot = b;
		float bite = Mth.sin(state.attackTime * Mth.PI) * 0.6f;
		head.xRot = state.xRot * DEG - bite;
		head.yRot = state.yRot * DEG;
		tail.yRot = Mth.cos(state.ageInTicks * 0.2f) * 0.25f + Mth.cos(swing * 0.6662f) * 0.2f * amount;
	}
}
