package com.cultivation.client.model;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Skill-learning animation (50 ticks): the scroll glows in the hand, glyph plates rise around the
 * player, Qi orbs stream from the hand into the body and a ring rises around the player.
 */
public class LearnModel extends GlowModel {
	private static final float PALM_X = 5.0f;
	private static final float PALM_Y = 9.0f;
	private static final float PALM_Z = -9.0f;

	private final ModelPart palmGlow;
	private final ModelPart ring;
	private final ModelPart glyphs;
	private final ModelPart[] streams = new ModelPart[4];

	public LearnModel(ModelPart root) {
		super(root);
		this.palmGlow = root.getChild("palm_glow");
		this.ring = root.getChild("ring");
		this.glyphs = root.getChild("glyphs");
		for (int k = 0; k < streams.length; k++) {
			streams[k] = root.getChild("stream" + k);
		}
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("palm_glow", CubeListBuilder.create().texOffs(0, 0).addBox(-2, -2, -2, 4, 4, 4), PartPose.offset(PALM_X, PALM_Y, PALM_Z));
		root.addOrReplaceChild("ring", RingModel.ringBoxes(9, 1.5f, 1.0f), PartPose.offset(0, 22, 0));
		PartDefinition glyphs = root.addOrReplaceChild("glyphs", CubeListBuilder.create(), PartPose.offset(0, 14, 0));
		for (int k = 0; k < 6; k++) {
			double a = k * Math.PI / 3.0;
			glyphs.addOrReplaceChild("g" + k, CubeListBuilder.create().texOffs(0, 8)
				.addBox(-1.5f, -2, -0.3f, 3, 4, 0.6f).addBox(-0.4f, -1, -0.5f, 0.8f, 2, 1),
				PartPose.offsetAndRotation((float) (11.0 * Math.cos(a)), (k % 2) * -3.0f, (float) (11.0 * Math.sin(a)), 0, (float) (-a + Math.PI / 2.0), 0));
		}
		for (int k = 0; k < 4; k++) {
			root.addOrReplaceChild("stream" + k, CubeListBuilder.create().texOffs(0, 0).addBox(-0.8f, -0.8f, -0.8f, 1.6f, 1.6f, 1.6f),
				PartPose.offset(PALM_X, PALM_Y, PALM_Z));
		}
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float a = state.ageInTicks;
		float fadeOut = 1.0f - Mth.clamp((a - 38.0f) / 12.0f, 0.0f, 1.0f);

		float glow = Mth.clamp(a / 8.0f, 0.0f, 1.0f) * (0.7f + 0.3f * Mth.sin(a * 0.7f)) * fadeOut;
		scale(palmGlow, glow * 1.2f);

		float ringScale = Mth.clamp(a / 10.0f, 0.0f, 1.0f) * fadeOut;
		ring.y = 22.0f - Mth.clamp(a / 40.0f, 0.0f, 1.0f) * 20.0f;
		ring.yRot = a * 0.2f;
		ring.xScale = ringScale;
		ring.zScale = ringScale;
		ring.yScale = 1.0f;

		glyphs.y = 14.0f - Mth.clamp(a / 45.0f, 0.0f, 1.0f) * 16.0f;
		glyphs.yRot = a * 0.12f;
		scale(glyphs, Mth.clamp(a / 12.0f, 0.0f, 1.0f) * fadeOut);

		for (int k = 0; k < streams.length; k++) {
			float local = a - 6.0f - k * 7.0f;
			if (local < 0.0f || a >= 42.0f) {
				scale(streams[k], 0.0f);
				continue;
			}
			float f = (local % 20.0f) / 20.0f;
			streams[k].x = PALM_X * (1.0f - f);
			streams[k].y = PALM_Y + (12.0f - PALM_Y) * f;
			streams[k].z = PALM_Z * (1.0f - f);
			scale(streams[k], 1.0f);
		}
	}
}
