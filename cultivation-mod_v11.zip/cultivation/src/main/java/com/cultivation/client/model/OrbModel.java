package com.cultivation.client.model;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Glowing sphere with two spinning rings and an energy trail. Grows while charging at the palm,
 * then pulses while flying. Used by the Qi bolt (blue) and the fire bolt (orange).
 */
public class OrbModel extends GlowModel {
	private final ModelPart core;
	private final ModelPart shell;
	private final ModelPart rings;
	private final ModelPart rings2;
	private final ModelPart trail;

	public OrbModel(ModelPart root) {
		super(root);
		this.core = root.getChild("core");
		this.shell = root.getChild("shell");
		this.rings = root.getChild("rings");
		this.rings2 = root.getChild("rings2");
		this.trail = root.getChild("trail");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("core", CubeListBuilder.create().texOffs(0, 0).addBox(-3, -3, -3, 6, 6, 6), PartPose.offset(0, 20, 0));
		root.addOrReplaceChild("shell", CubeListBuilder.create().texOffs(0, 16).addBox(-4.5f, -4.5f, -4.5f, 9, 9, 9), PartPose.offset(0, 20, 0));
		CubeListBuilder ring = CubeListBuilder.create().texOffs(0, 36)
			.addBox(-8, -0.5f, -8, 16, 1, 2)
			.addBox(-8, -0.5f, 6, 16, 1, 2)
			.addBox(-8, -0.5f, -6, 2, 1, 12)
			.addBox(6, -0.5f, -6, 2, 1, 12);
		root.addOrReplaceChild("rings", ring, PartPose.offset(0, 20, 0));
		root.addOrReplaceChild("rings2", ring, PartPose.offsetAndRotation(0, 20, 0, 1.5708f, 0, 0));
		root.addOrReplaceChild("trail", CubeListBuilder.create().texOffs(0, 44)
			.addBox(-2, -2, 4, 4, 4, 6)
			.addBox(-1.2f, -1.2f, 10, 2.4f, 2.4f, 6)
			.addBox(-0.6f, -0.6f, 16, 1.2f, 1.2f, 6), PartPose.offset(0, 20, 0));
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(CultivationRenderState state) {
		super.setupAnim(state);
		float age = state.ageInTicks;
		float grow = Mth.clamp(0.3f + age * 0.14f, 0.3f, 1.0f);
		float s = grow * (1.0f + 0.08f * Mth.sin(age * 0.9f));
		scale(core, s);
		scale(shell, s);
		scale(rings, s);
		scale(rings2, s);
		scale(trail, grow);
		core.yRot = age * 0.2f;
		rings.yRot = age * 0.5f;
		rings.zRot = age * 0.3f;
		rings2.xRot = 1.5708f + age * 0.25f;
		rings2.yRot = -age * 0.4f;
	}
}
