package com.cultivation.loot;

import com.cultivation.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

/**
 * Adds scrolls and swords to vanilla chest loot with low chances. Nothing is ever given
 * automatically; items are only found in chests.
 */
public final class ModLoot {
	private record Entry(ResourceKey<LootTable> table, Item item, float chance) {
	}

	private static final Entry[] ENTRIES = {
		// Common swords
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.PLAIN_IRON_SWORD, 0.20f),
		new Entry(BuiltInLootTables.VILLAGE_WEAPONSMITH, ModItems.PLAIN_IRON_SWORD, 0.30f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.PLAIN_IRON_SWORD, 0.10f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.RUSTY_SWORD, 0.20f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.RUSTY_SWORD, 0.18f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.RUSTY_SWORD, 0.10f),
		new Entry(BuiltInLootTables.JUNGLE_TEMPLE, ModItems.RUSTY_SWORD, 0.10f),
		// Rarer swords
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.BLACK_IRON_SWORD, 0.08f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.BLACK_IRON_SWORD, 0.06f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.SILVER_SWORD, 0.04f),
		new Entry(BuiltInLootTables.STRONGHOLD_CORRIDOR, ModItems.SILVER_SWORD, 0.04f),
		new Entry(BuiltInLootTables.VILLAGE_WEAPONSMITH, ModItems.SILVER_SWORD, 0.05f),
		// Scrolls
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.QI_BOLT_MANUAL, 0.15f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.QI_BOLT_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.QI_BOLT_MANUAL, 0.10f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.AZURE_SWORD_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.JUNGLE_TEMPLE, ModItems.AZURE_SWORD_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.STRONGHOLD_LIBRARY, ModItems.AZURE_SWORD_MANUAL, 0.15f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.WIND_PALM_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.WIND_PALM_MANUAL, 0.10f),
		new Entry(BuiltInLootTables.VILLAGE_WEAPONSMITH, ModItems.WIND_PALM_MANUAL, 0.10f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.EARTH_SHOCK_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.EARTH_SHOCK_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.EARTH_SHOCK_MANUAL, 0.10f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.WIND_STEP_MANUAL, 0.10f),
		new Entry(BuiltInLootTables.JUNGLE_TEMPLE, ModItems.WIND_STEP_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.STRONGHOLD_CORRIDOR, ModItems.WIND_STEP_MANUAL, 0.10f),
		// Tier 2-10 swords: rarer tiers only in deep / ancient structures
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.JADE_GREEN_SWORD, 0.06f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.JADE_GREEN_SWORD, 0.05f),
		new Entry(BuiltInLootTables.VILLAGE_WEAPONSMITH, ModItems.JADE_GREEN_SWORD, 0.06f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.WIND_EDGE_SWORD, 0.05f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.WIND_EDGE_SWORD, 0.05f),
		new Entry(BuiltInLootTables.JUNGLE_TEMPLE, ModItems.AZURE_QI_SWORD, 0.05f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.AZURE_QI_SWORD, 0.05f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.MOLTEN_FLAME_SWORD, 0.04f),
		new Entry(BuiltInLootTables.NETHER_BRIDGE, ModItems.MOLTEN_FLAME_SWORD, 0.05f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.INDIGO_SPIRIT_SWORD, 0.03f),
		new Entry(BuiltInLootTables.STRONGHOLD_CORRIDOR, ModItems.INDIGO_SPIRIT_SWORD, 0.03f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.INDIGO_SPIRIT_SWORD, 0.015f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.MOON_SWORD, 0.03f),
		new Entry(BuiltInLootTables.STRONGHOLD_LIBRARY, ModItems.MOON_SWORD, 0.03f),
		new Entry(BuiltInLootTables.JUNGLE_TEMPLE, ModItems.MOON_SWORD, 0.02f),
		new Entry(BuiltInLootTables.WOODLAND_MANSION, ModItems.PHANTOM_SHADOW_SWORD, 0.03f),
		new Entry(BuiltInLootTables.PILLAGER_OUTPOST, ModItems.PHANTOM_SHADOW_SWORD, 0.02f),
		new Entry(BuiltInLootTables.BASTION_TREASURE, ModItems.MYSTIC_THUNDER_SWORD, 0.03f),
		new Entry(BuiltInLootTables.BURIED_TREASURE, ModItems.MYSTIC_THUNDER_SWORD, 0.025f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.MOUNTAIN_STONE_SWORD, 0.015f),
		new Entry(BuiltInLootTables.STRONGHOLD_CORRIDOR, ModItems.MOUNTAIN_STONE_SWORD, 0.02f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.MOUNTAIN_STONE_SWORD, 0.02f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.EARTH_CORE_SWORD, 0.02f),
		new Entry(BuiltInLootTables.BASTION_TREASURE, ModItems.EARTH_CORE_SWORD, 0.02f),
		new Entry(BuiltInLootTables.END_CITY_TREASURE, ModItems.HEAVEN_CLOUD_SWORD, 0.02f),
		new Entry(BuiltInLootTables.WOODLAND_MANSION, ModItems.HEAVEN_CLOUD_SWORD, 0.015f),
		new Entry(BuiltInLootTables.END_CITY_TREASURE, ModItems.HEAVEN_THUNDER_SWORD, 0.015f),
		new Entry(BuiltInLootTables.BASTION_TREASURE, ModItems.HEAVEN_THUNDER_SWORD, 0.015f),
		new Entry(BuiltInLootTables.END_CITY_TREASURE, ModItems.DRAGON_MONARCH_SWORD, 0.01f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.DRAGON_MONARCH_SWORD, 0.01f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.BLOOD_MONARCH_SWORD, 0.01f),
		new Entry(BuiltInLootTables.BASTION_TREASURE, ModItems.BLOOD_MONARCH_SWORD, 0.01f),
		new Entry(BuiltInLootTables.END_CITY_TREASURE, ModItems.SKY_EMPEROR_SWORD, 0.008f),
		new Entry(BuiltInLootTables.WOODLAND_MANSION, ModItems.SKY_EMPEROR_SWORD, 0.006f),
		new Entry(BuiltInLootTables.END_CITY_TREASURE, ModItems.VOID_EMPEROR_SWORD, 0.008f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.VOID_EMPEROR_SWORD, 0.006f),
		new Entry(BuiltInLootTables.END_CITY_TREASURE, ModItems.WIND_IMMORTAL_SWORD, 0.006f),
		new Entry(BuiltInLootTables.END_CITY_TREASURE, ModItems.ETERNAL_IMMORTAL_SWORD, 0.006f),
		new Entry(BuiltInLootTables.ANCIENT_CITY, ModItems.ETERNAL_IMMORTAL_SWORD, 0.005f),
	};

	private ModLoot() {
	}

	public static void register() {
		LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
			if (!source.isBuiltin()) {
				return;
			}
			for (Entry entry : ENTRIES) {
				if (entry.table().equals(key)) {
					LootPool.Builder pool = LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0f))
						.when(LootItemRandomChanceCondition.randomChance(entry.chance()))
						.add(LootItem.lootTableItem(entry.item()));
					tableBuilder.withPool(pool);
				}
			}
		});
	}
}
