package com.cultivation.item;

import com.cultivation.CultivationMod;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

/**
 * The mod's own Creative tabs, separate from vanilla tabs. Each item is listed in exactly one
 * tab (no duplicate items are created). Order inside a tab is by type, then by tier.
 */
public final class ModCreativeTabs {
	private ModCreativeTabs() {
	}

	private static ResourceKey<CreativeModeTab> key(String name) {
		return ResourceKey.create(BuiltInRegistries.CREATIVE_MODE_TAB.key(), CultivationMod.id(name));
	}

	public static void init() {
		// คัมภีร์บ่มเพาะ: attack skills first, then movement skills.
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key("scrolls"), FabricCreativeModeTab.builder()
			.icon(() -> new ItemStack(ModItems.QI_BOLT_MANUAL))
			.title(Component.translatable("creativeTab.cultivation.scrolls"))
			.displayItems((params, output) -> {
				// Attack
				output.accept(ModItems.QI_BOLT_MANUAL);
				output.accept(ModItems.AZURE_SWORD_MANUAL);
				output.accept(ModItems.WIND_PALM_MANUAL);
				output.accept(ModItems.EARTH_SHOCK_MANUAL);
				// Movement
				output.accept(ModItems.WIND_STEP_MANUAL);
			})
			.build());

		// กระบี่และอาวุธ: tier 1 (common) first, then tiers 2-10.
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key("weapons"), FabricCreativeModeTab.builder()
			.icon(() -> new ItemStack(ModItems.ETERNAL_IMMORTAL_SWORD))
			.title(Component.translatable("creativeTab.cultivation.weapons"))
			.displayItems((params, output) -> {
				output.accept(ModItems.RUSTY_SWORD);
				output.accept(ModItems.PLAIN_IRON_SWORD);
				output.accept(ModItems.BRONZE_SWORD);
				output.accept(ModItems.BLACK_IRON_SWORD);
				output.accept(ModItems.SILVER_SWORD);
				output.accept(ModItems.JADE_GREEN_SWORD);
				output.accept(ModItems.WIND_EDGE_SWORD);
				output.accept(ModItems.AZURE_QI_SWORD);
				output.accept(ModItems.MOLTEN_FLAME_SWORD);
				output.accept(ModItems.INDIGO_SPIRIT_SWORD);
				output.accept(ModItems.MOON_SWORD);
				output.accept(ModItems.PHANTOM_SHADOW_SWORD);
				output.accept(ModItems.MYSTIC_THUNDER_SWORD);
				output.accept(ModItems.MOUNTAIN_STONE_SWORD);
				output.accept(ModItems.EARTH_CORE_SWORD);
				output.accept(ModItems.HEAVEN_CLOUD_SWORD);
				output.accept(ModItems.HEAVEN_THUNDER_SWORD);
				output.accept(ModItems.DRAGON_MONARCH_SWORD);
				output.accept(ModItems.BLOOD_MONARCH_SWORD);
				output.accept(ModItems.SKY_EMPEROR_SWORD);
				output.accept(ModItems.VOID_EMPEROR_SWORD);
				output.accept(ModItems.WIND_IMMORTAL_SWORD);
				output.accept(ModItems.ETERNAL_IMMORTAL_SWORD);
			})
			.build());

		// วัตถุดิบบ่มเพาะ: beast materials grouped per beast.
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key("materials"), FabricCreativeModeTab.builder()
			.icon(() -> new ItemStack(ModItems.WIND_CORE))
			.title(Component.translatable("creativeTab.cultivation.materials"))
			.displayItems((params, output) -> {
				output.accept(ModItems.WOLF_FANG);
				output.accept(ModItems.WIND_CORE);
				output.accept(ModItems.STONE_FANG);
				output.accept(ModItems.STONE_ARMOR_SHARD);
				output.accept(ModItems.FLAME_CORE);
				output.accept(ModItems.SPIRIT_FOX_FUR);
			})
			.build());

		// ไข่เรียกสัตว์อสูร: ordered from the weakest beast (by health) to the strongest.
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key("spawn_eggs"), FabricCreativeModeTab.builder()
			.icon(() -> new ItemStack(ModItems.BLUE_WIND_WOLF_SPAWN_EGG))
			.title(Component.translatable("creativeTab.cultivation.spawn_eggs"))
			.displayItems((params, output) -> {
				output.accept(ModItems.BLUE_WIND_WOLF_SPAWN_EGG);
				output.accept(ModItems.FLAME_FOX_SPAWN_EGG);
				output.accept(ModItems.STONE_ARMOR_BOAR_SPAWN_EGG);
			})
			.build());
	}
}
