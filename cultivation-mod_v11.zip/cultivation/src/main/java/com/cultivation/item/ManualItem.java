package com.cultivation.item;

import com.cultivation.skill.SkillService;
import com.cultivation.skill.SkillType;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** A scroll that teaches exactly one skill. It is consumed only when the skill is learned. */
public class ManualItem extends Item {
	private final SkillType skill;

	public ManualItem(Item.Properties properties, SkillType skill) {
		super(properties);
		this.skill = skill;
	}

	public SkillType skill() {
		return skill;
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide() || !(player instanceof ServerPlayer serverPlayer)) {
			return InteractionResult.SUCCESS;
		}
		ItemStack stack = player.getItemInHand(hand);
		SkillService.LearnResult result = SkillService.learn(serverPlayer, skill);
		if (result == SkillService.LearnResult.LEARNED) {
			stack.consume(1, player);
			return InteractionResult.CONSUME;
		}
		return InteractionResult.FAIL;
	}
}
