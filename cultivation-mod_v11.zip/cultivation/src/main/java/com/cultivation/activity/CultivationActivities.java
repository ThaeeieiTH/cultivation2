package com.cultivation.activity;

import com.cultivation.CultivationConfig;
import com.cultivation.data.CultivationStore;
import com.cultivation.entity.BeastEntity;
import com.cultivation.progression.ProgressionService;
import com.cultivation.skill.SkillService;
import com.cultivation.skill.SkillType;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.projectile.Projectile;

/**
 * Experience and training from kills. Only vanilla-style monsters and the mod's spirit beasts
 * (every BeastEntity, including future ones) give experience; ordinary animals never do.
 */
public final class CultivationActivities {
	private static final Set<UUID> REWARDED = new HashSet<>();
	private static final int TRAINING_PER_KILL = 4;

	private CultivationActivities() {
	}

	public static boolean givesExperience(LivingEntity entity) {
		return entity instanceof BeastEntity || entity.getType().getCategory() == MobCategory.MONSTER;
	}

	public static void register() {
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(source.getEntity() instanceof ServerPlayer player)) {
				return;
			}
			if (!givesExperience(entity)) {
				return;
			}
			// A single death must never reward twice.
			if (!REWARDED.add(entity.getUUID())) {
				return;
			}
			if (REWARDED.size() > 1024) {
				REWARDED.clear();
				REWARDED.add(entity.getUUID());
			}
			long required = CultivationStore.get(player).requiredExperience();
			long gain = Math.max(CultivationConfig.KILL_EXP_MIN, required / CultivationConfig.KILL_EXP_DIVISOR);
			ProgressionService.addExperience(player, gain);
			trainFromKill(player, source);
		});
	}

	/** Each skill trains only from its own kind of activity. */
	private static void trainFromKill(ServerPlayer player, DamageSource source) {
		Entity direct = source.getDirectEntity();
		if (direct instanceof Projectile) {
			SkillService.train(player, SkillType.QI_BOLT, TRAINING_PER_KILL);
		} else if (direct == player && player.getMainHandItem().is(ItemTags.SWORDS)) {
			SkillService.train(player, SkillType.AZURE_SWORD, TRAINING_PER_KILL);
		}
	}
}
