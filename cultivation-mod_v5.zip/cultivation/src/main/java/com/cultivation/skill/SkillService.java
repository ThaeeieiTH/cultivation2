package com.cultivation.skill;

import com.cultivation.data.CultivationData;
import com.cultivation.data.CultivationStore;
import com.cultivation.entity.AzureWaveEntity;
import com.cultivation.entity.ModEntities;
import com.cultivation.entity.QiBoltEntity;
import com.cultivation.progression.CultivationRealm;
import com.cultivation.qi.QiService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;

/** Server-authoritative learning, training, selecting and casting of skills. */
public final class SkillService {
	private static final Map<UUID, Long> COOLDOWN_UNTIL = new HashMap<>();

	public enum LearnResult {
		LEARNED,
		ALREADY_LEARNED,
		REALM_TOO_LOW
	}

	private SkillService() {
	}

	private static void say(ServerPlayer player, String text) {
		player.sendSystemMessage(Component.literal(text));
	}

	public static LearnResult learn(ServerPlayer player, SkillType skill) {
		SkillData data = SkillStore.get(player);
		if (data.isLearned(skill.id())) {
			say(player, "คุณเรียนรู้" + skill.thaiName() + "แล้ว ไม่สามารถเรียนซ้ำได้");
			return LearnResult.ALREADY_LEARNED;
		}
		CultivationData cultivation = CultivationStore.get(player);
		if (cultivation.realm() < skill.minRealm()) {
			say(player, "ต้องมีระดับพลังบ่มเพาะ " + CultivationRealm.byIndex(skill.minRealm()).thaiName() + " ขึ้นไปจึงจะเรียนได้");
			return LearnResult.REALM_TOO_LOW;
		}
		SkillStore.set(player, data.learn(skill.id()));
		say(player, "เรียนรู้" + skill.thaiName() + "สำเร็จ! ฝึกความชำนาญให้ถึง 100 (กด N ดูความคืบหน้า) จึงจะใช้วิชาได้");
		return LearnResult.LEARNED;
	}

	/** Adds proficiency to one skill only. Ignored for skills that are not learned or already mastered. */
	public static void train(ServerPlayer player, SkillType skill, int amount) {
		if (amount <= 0) {
			return;
		}
		SkillData data = SkillStore.get(player);
		int current = data.proficiency(skill.id());
		if (current < 0 || current >= SkillType.MAX_PROFICIENCY) {
			return;
		}
		int next = Math.min(SkillType.MAX_PROFICIENCY, current + amount);
		SkillStore.set(player, data.withProficiency(skill.id(), next));
		if (next >= SkillType.MAX_PROFICIENCY) {
			say(player, "สำเร็จวิชา " + skill.thaiName() + " แล้ว! กด V เพื่อเลือกวิชา และ R เพื่อใช้วิชา");
		}
	}

	/** V key: cycle to the next learned and mastered skill. */
	public static void selectNext(ServerPlayer player) {
		SkillData data = SkillStore.get(player);
		List<SkillType> ready = new ArrayList<>();
		for (SkillType type : SkillType.values()) {
			if (data.isMastered(type.id())) {
				ready.add(type);
			}
		}
		if (ready.isEmpty()) {
			say(player, "ยังไม่มีวิชาที่พร้อมใช้งาน ต้องเรียนวิชาและฝึกความชำนาญให้ถึง 100");
			return;
		}
		int index = -1;
		for (int i = 0; i < ready.size(); i++) {
			if (ready.get(i).id().equals(data.selected())) {
				index = i;
			}
		}
		SkillType next = ready.get((index + 1) % ready.size());
		SkillStore.set(player, data.withSelected(next.id()));
		say(player, "เลือกวิชา: " + next.thaiName());
	}

	/** R key: cast the selected skill after every server-side check. */
	public static void use(ServerPlayer player) {
		SkillData data = SkillStore.get(player);
		SkillType skill = SkillType.byId(data.selected());
		if (skill == null) {
			say(player, "ยังไม่ได้เลือกวิชา กด V เพื่อเลือกวิชาที่พร้อมใช้งาน");
			return;
		}
		if (!data.isMastered(skill.id())) {
			say(player, "ยังฝึก" + skill.thaiName() + "ไม่ถึง 100 จึงใช้ไม่ได้");
			return;
		}
		if (CultivationStore.get(player).realm() < skill.minRealm()) {
			say(player, "ระดับพลังบ่มเพาะไม่เพียงพอสำหรับวิชานี้");
			return;
		}
		if (skill.requiresSword() && !player.getMainHandItem().is(ItemTags.SWORDS)) {
			say(player, "ต้องถือกระบี่เพื่อใช้วิชานี้");
			return;
		}
		ServerLevel level = (ServerLevel) player.level();
		long now = level.getGameTime();
		Long until = COOLDOWN_UNTIL.get(player.getUUID());
		if (until != null && now < until) {
			say(player, "วิชากำลังคูลดาวน์ อีก " + String.format("%.1f", (until - now) / 20.0) + " วินาที");
			return;
		}
		if (!QiService.consumeQi(player, skill.qiCost())) {
			say(player, "ปราณไม่เพียงพอ ต้องใช้ " + skill.qiCost() + " หน่วย");
			return;
		}
		COOLDOWN_UNTIL.put(player.getUUID(), now + skill.cooldownTicks());
		switch (skill) {
			case QI_BOLT -> {
				QiBoltEntity bolt = new QiBoltEntity(ModEntities.QI_BOLT, level);
				bolt.setup(player, skill.damage());
				level.addFreshEntity(bolt);
			}
			case AZURE_SWORD -> {
				player.swing(InteractionHand.MAIN_HAND);
				AzureWaveEntity wave = new AzureWaveEntity(ModEntities.AZURE_WAVE, level);
				wave.setup(player, skill.damage());
				level.addFreshEntity(wave);
			}
		}
	}

	public static void forget(UUID id) {
		COOLDOWN_UNTIL.remove(id);
	}
}
