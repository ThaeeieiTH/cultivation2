package com.cultivation.skill;

/** All learnable skills. Each skill has its own proficiency (0-100) stored per player. */
public enum SkillType {
	QI_BOLT("qi_bolt", "วิชาลูกปราณ", "โจมตีระยะไกล", 15, 60, 6.0f, false, 0,
		"รวมพลังปราณไว้ที่ฝ่ามือ แล้วปล่อยเป็นลูกพลังปราณสีฟ้าอัดแน่น พุ่งเข้าโจมตีศัตรูจากระยะไกล"),
	AZURE_SWORD("azure_sword", "กระบี่ปราณฟ้า", "วิชากระบี่โจมตีระยะไกล", 15, 60, 6.0f, true, 0,
		"รวบรวมปราณเข้าสู่กระบี่ แล้วฟาดฟันปลดปล่อยคลื่นกระบี่สีฟ้าเพื่อโจมตีศัตรูจากระยะไกล");

	public static final int MAX_PROFICIENCY = 100;

	private final String id;
	private final String thaiName;
	private final String kind;
	private final int qiCost;
	private final int cooldownTicks;
	private final float damage;
	private final boolean requiresSword;
	private final int minRealm;
	private final String description;

	SkillType(String id, String thaiName, String kind, int qiCost, int cooldownTicks, float damage,
		boolean requiresSword, int minRealm, String description) {
		this.id = id;
		this.thaiName = thaiName;
		this.kind = kind;
		this.qiCost = qiCost;
		this.cooldownTicks = cooldownTicks;
		this.damage = damage;
		this.requiresSword = requiresSword;
		this.minRealm = minRealm;
		this.description = description;
	}

	public String id() {
		return id;
	}

	public String thaiName() {
		return thaiName;
	}

	public String kind() {
		return kind;
	}

	public int qiCost() {
		return qiCost;
	}

	public int cooldownTicks() {
		return cooldownTicks;
	}

	public float damage() {
		return damage;
	}

	public boolean requiresSword() {
		return requiresSword;
	}

	/** Minimum cultivation realm index (0 = สร้างลมปราณ) needed to learn the skill. */
	public int minRealm() {
		return minRealm;
	}

	public String description() {
		return description;
	}

	public static SkillType byId(String id) {
		for (SkillType type : values()) {
			if (type.id.equals(id)) {
				return type;
			}
		}
		return null;
	}

	public static String tier(int proficiency) {
		if (proficiency >= 100) {
			return "สำเร็จวิชา";
		}
		if (proficiency >= 80) {
			return "ปรมาจารย์";
		}
		if (proficiency >= 60) {
			return "เชี่ยวชาญ";
		}
		if (proficiency >= 40) {
			return "ชำนาญ";
		}
		if (proficiency >= 20) {
			return "ขั้นพื้นฐาน";
		}
		return "มือใหม่";
	}
}
