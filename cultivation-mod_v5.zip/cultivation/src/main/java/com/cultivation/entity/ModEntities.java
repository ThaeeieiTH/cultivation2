package com.cultivation.entity;

import com.cultivation.CultivationMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.level.levelgen.Heightmap;

/** Registers the 3 spirit beasts and the skill effect entities, and the natural spawns. */
public final class ModEntities {
	public static final EntityType<BlueWindWolf> BLUE_WIND_WOLF = register("blue_wind_wolf",
		EntityType.Builder.<BlueWindWolf>of(BlueWindWolf::new, MobCategory.MONSTER).sized(0.7f, 0.85f).clientTrackingRange(8),
		BlueWindWolf.createAttributes());
	public static final EntityType<StoneArmorBoar> STONE_ARMOR_BOAR = register("stone_armor_boar",
		EntityType.Builder.<StoneArmorBoar>of(StoneArmorBoar::new, MobCategory.MONSTER).sized(1.0f, 1.0f).clientTrackingRange(8),
		StoneArmorBoar.createAttributes());
	public static final EntityType<FlameFox> FLAME_FOX = register("flame_fox",
		EntityType.Builder.<FlameFox>of(FlameFox::new, MobCategory.MONSTER).sized(0.6f, 0.7f).clientTrackingRange(8),
		FlameFox.createAttributes());

	public static final EntityType<QiBoltEntity> QI_BOLT = register("qi_bolt",
		EntityType.Builder.<QiBoltEntity>of(QiBoltEntity::new, MobCategory.MISC).sized(0.5f, 0.5f).clientTrackingRange(10).updateInterval(1),
		EffectEntity.createEffectAttributes());
	public static final EntityType<AzureWaveEntity> AZURE_WAVE = register("azure_wave",
		EntityType.Builder.<AzureWaveEntity>of(AzureWaveEntity::new, MobCategory.MISC).sized(0.8f, 0.8f).clientTrackingRange(10).updateInterval(1),
		EffectEntity.createEffectAttributes());
	public static final EntityType<FireBoltEntity> FIRE_BOLT = register("fire_bolt",
		EntityType.Builder.<FireBoltEntity>of(FireBoltEntity::new, MobCategory.MISC).sized(0.4f, 0.4f).clientTrackingRange(10).updateInterval(1),
		EffectEntity.createEffectAttributes());
	public static final EntityType<BurstEntity> BURST = register("burst",
		EntityType.Builder.<BurstEntity>of(BurstEntity::new, MobCategory.MISC).sized(0.5f, 0.5f).clientTrackingRange(10).updateInterval(1),
		EffectEntity.createEffectAttributes());

	private ModEntities() {
	}

	private static <T extends Entity> EntityType<T> registerType(ResourceKey<EntityType<?>> key, EntityType.Builder<T> builder) {
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
	}

	private static <T extends LivingEntity> EntityType<T> register(String name, EntityType.Builder<T> builder, AttributeSupplier.Builder attributes) {
		ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, CultivationMod.id(name));
		EntityType<T> type = registerType(key, builder);
		FabricDefaultAttributeRegistry.register(type, attributes);
		return type;
	}

	public static void init() {
		SpawnPlacements.register(BLUE_WIND_WOLF, SpawnPlacementTypes.ON_GROUND,
			Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
		SpawnPlacements.register(STONE_ARMOR_BOAR, SpawnPlacementTypes.ON_GROUND,
			Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
		SpawnPlacements.register(FLAME_FOX, SpawnPlacementTypes.ON_GROUND,
			Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);

		// Wolves: forests and grasslands. Boars: forests and mountains. Foxes: forests and warm biomes (rarer).
		BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_FOREST), MobCategory.MONSTER, BLUE_WIND_WOLF, 6, 2, 4);
		BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_TAIGA), MobCategory.MONSTER, BLUE_WIND_WOLF, 5, 2, 4);
		BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_FOREST), MobCategory.MONSTER, STONE_ARMOR_BOAR, 4, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_MOUNTAIN), MobCategory.MONSTER, STONE_ARMOR_BOAR, 5, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_FOREST), MobCategory.MONSTER, FLAME_FOX, 1, 1, 1);
		BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_SAVANNA), MobCategory.MONSTER, FLAME_FOX, 2, 1, 1);
		BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_BADLANDS), MobCategory.MONSTER, FLAME_FOX, 2, 1, 1);
	}
}
