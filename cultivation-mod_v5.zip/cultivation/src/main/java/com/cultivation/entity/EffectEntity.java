package com.cultivation.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/**
 * Base for the mod's own skill effects. They are rendered by custom models/textures (no vanilla
 * particles), cannot be attacked, pushed or saved.
 */
public abstract class EffectEntity extends PathfinderMob {
	protected EffectEntity(EntityType<? extends EffectEntity> type, Level level) {
		super(type, level);
		this.noPhysics = true;
		this.setNoGravity(true);
		this.setInvulnerable(true);
	}

	public static AttributeSupplier.Builder createEffectAttributes() {
		return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, 1.0);
	}

	@Override
	protected void registerGoals() {
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	public boolean isAttackable() {
		return false;
	}

	public boolean shouldBeSaved() {
		return false;
	}
}
