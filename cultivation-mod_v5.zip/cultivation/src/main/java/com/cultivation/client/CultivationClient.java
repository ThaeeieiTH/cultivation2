package com.cultivation.client;

import com.cultivation.client.model.BurstModel;
import com.cultivation.client.model.CrescentModel;
import com.cultivation.client.model.ModEntityModelLayers;
import com.cultivation.client.model.OrbModel;
import com.cultivation.client.render.BeastRenderer;
import com.cultivation.client.render.EffectRenderer;
import com.cultivation.CultivationMod;
import com.cultivation.entity.ModEntities;
import com.cultivation.network.ActionPayload;
import com.cultivation.network.CultivationSyncPayload;
import com.cultivation.network.SkillSyncPayload;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.EntityRenderers;

public final class CultivationClient implements ClientModInitializer {
	private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(CultivationMod.id("cultivation"));

	public static final KeyMapping BREAKTHROUGH_KEY = KeyMappingHelper.registerKeyMapping(
		new KeyMapping("key.cultivation.breakthrough", InputConstants.Type.KEYSYM, InputConstants.KEY_M, CATEGORY));
	public static final KeyMapping SKILLS_KEY = KeyMappingHelper.registerKeyMapping(
		new KeyMapping("key.cultivation.skills", InputConstants.Type.KEYSYM, InputConstants.KEY_N, CATEGORY));
	public static final KeyMapping NEXT_SKILL_KEY = KeyMappingHelper.registerKeyMapping(
		new KeyMapping("key.cultivation.next_skill", InputConstants.Type.KEYSYM, InputConstants.KEY_V, CATEGORY));
	public static final KeyMapping USE_SKILL_KEY = KeyMappingHelper.registerKeyMapping(
		new KeyMapping("key.cultivation.use_skill", InputConstants.Type.KEYSYM, InputConstants.KEY_R, CATEGORY));

	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(CultivationSyncPayload.TYPE,
			(payload, context) -> ClientCultivationState.set(payload));
		ClientPlayNetworking.registerGlobalReceiver(SkillSyncPayload.TYPE,
			(payload, context) -> ClientSkillState.set(payload));
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
			ClientCultivationState.clear();
			ClientSkillState.clear();
		});
		CultivationHud.register();

		ModEntityModelLayers.register();
		EntityRenderers.register(ModEntities.BLUE_WIND_WOLF,
			context -> new BeastRenderer<>(context, ModEntityModelLayers.WOLF, "blue_wind_wolf", 0.5f));
		EntityRenderers.register(ModEntities.STONE_ARMOR_BOAR,
			context -> new BeastRenderer<>(context, ModEntityModelLayers.BOAR, "stone_armor_boar", 0.8f));
		EntityRenderers.register(ModEntities.FLAME_FOX,
			context -> new BeastRenderer<>(context, ModEntityModelLayers.FOX, "flame_fox", 0.4f));
		EntityRenderers.register(ModEntities.QI_BOLT,
			context -> new EffectRenderer<>(context, new OrbModel(context.bakeLayer(ModEntityModelLayers.ORB)), "qi_bolt"));
		EntityRenderers.register(ModEntities.FIRE_BOLT,
			context -> new EffectRenderer<>(context, new OrbModel(context.bakeLayer(ModEntityModelLayers.ORB)), "fire_bolt"));
		EntityRenderers.register(ModEntities.AZURE_WAVE,
			context -> new EffectRenderer<>(context, new CrescentModel(context.bakeLayer(ModEntityModelLayers.CRESCENT)), "azure_wave"));
		EntityRenderers.register(ModEntities.BURST,
			context -> new EffectRenderer<>(context, new BurstModel(context.bakeLayer(ModEntityModelLayers.BURST)), "burst"));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null) {
				return;
			}
			while (BREAKTHROUGH_KEY.consumeClick()) {
				ClientPlayNetworking.send(new ActionPayload(ActionPayload.BREAKTHROUGH));
			}
			while (NEXT_SKILL_KEY.consumeClick()) {
				ClientPlayNetworking.send(new ActionPayload(ActionPayload.NEXT_SKILL));
			}
			while (USE_SKILL_KEY.consumeClick()) {
				ClientPlayNetworking.send(new ActionPayload(ActionPayload.USE_SKILL));
			}
			while (SKILLS_KEY.consumeClick()) {
				client.gui.setScreen(new SkillScreen());
			}
		});
	}
}
