package com.cultivation.client;

import com.cultivation.network.ActionPayload;
import com.cultivation.network.SkillSyncPayload;
import com.cultivation.skill.SkillType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Skill proficiency screen (N). Lists every learned skill with proficiency, progress bar, tier and
 * status. The buttons double as touch controls for switching skills, casting and breaking through.
 */
public class SkillScreen extends Screen {
	private static final int ROW_HEIGHT = 38;
	private static final int PANEL_WIDTH = 270;

	public SkillScreen() {
		super(Component.literal("วิชาและความชำนาญ"));
	}

	public boolean isPauseScreen() {
		return false;
	}

	@Override
	protected void init() {
		int left = (this.width - 252) / 2;
		int y = this.height - 30;
		this.addRenderableWidget(Button.builder(Component.literal("สลับวิชา (V)"), b -> send(ActionPayload.NEXT_SKILL))
			.bounds(left, y, 60, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("ใช้วิชา (R)"), b -> send(ActionPayload.USE_SKILL))
			.bounds(left + 64, y, 60, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("ทะลวง (M)"), b -> send(ActionPayload.BREAKTHROUGH))
			.bounds(left + 128, y, 60, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("ปิด (N)"), b -> this.onClose())
			.bounds(left + 192, y, 60, 20).build());
		ScreenKeyboardEvents.beforeKeyPress(this).register((screen, keyEvent) -> {
			if (CultivationClient.SKILLS_KEY.matches(keyEvent)) {
				this.onClose();
			}
		});
	}

	private static void send(int action) {
		ClientPlayNetworking.send(new ActionPayload(action));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		SkillSyncPayload state = ClientSkillState.get();
		int left = (this.width - PANEL_WIDTH) / 2;
		int top = 12;
		int bottom = this.height - 38;
		graphics.fill(left, top, left + PANEL_WIDTH, bottom, 0xC0101018);
		graphics.outline(left, top, PANEL_WIDTH, bottom - top, 0xFF6B5B2A);
		graphics.text(this.font, "วิชาและความชำนาญ", left + 8, top + 6, 0xFFFFD75E, true);

		int y = top + 22;
		int shown = 0;
		for (SkillType skill : SkillType.values()) {
			int proficiency = state.proficiency(skill.id());
			if (proficiency < 0) {
				continue;
			}
			if (y + ROW_HEIGHT > bottom) {
				break;
			}
			boolean mastered = proficiency >= SkillType.MAX_PROFICIENCY;
			boolean selected = skill.id().equals(state.selected());
			String title = skill.thaiName() + (selected ? "  [กำลังเลือกใช้]" : "");
			graphics.text(this.font, title, left + 8, y, selected ? 0xFF7CFF7C : 0xFFFFFFFF, true);
			String value = proficiency + " / " + SkillType.MAX_PROFICIENCY;
			graphics.text(this.font, value, left + PANEL_WIDTH - 8 - this.font.width(value), y, 0xFFFFFFFF, true);
			int barWidth = PANEL_WIDTH - 16;
			int barY = y + 12;
			graphics.fill(left + 8, barY, left + 8 + barWidth, barY + 6, 0xFF1B1B1B);
			int filled = Math.round(barWidth * (proficiency / (float) SkillType.MAX_PROFICIENCY));
			if (filled > 0) {
				graphics.fill(left + 8, barY, left + 8 + filled, barY + 6, mastered ? 0xFFE8B923 : 0xFF3FA7FF);
			}
			graphics.outline(left + 8, barY, barWidth, 6, 0xFF000000);
			String status = "ระดับ: " + SkillType.tier(proficiency) + "   สถานะ: " + (mastered ? "สำเร็จวิชาแล้ว" : "กำลังฝึก");
			graphics.text(this.font, status, left + 8, y + 22, 0xFFB8B8B8, true);
			y += ROW_HEIGHT;
			shown++;
		}
		if (shown == 0) {
			graphics.text(this.font, "ยังไม่ได้เรียนวิชาใด ใช้คัมภีร์เพื่อเรียนวิชา", left + 8, top + 30, 0xFFB8B8B8, true);
		}
	}
}
