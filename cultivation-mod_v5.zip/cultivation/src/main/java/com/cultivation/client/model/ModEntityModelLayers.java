package com.cultivation.client.model;

import com.cultivation.CultivationMod;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;

public final class ModEntityModelLayers {
	public static final ModelLayerLocation ORB = main("orb");
	public static final ModelLayerLocation CRESCENT = main("crescent");
	public static final ModelLayerLocation BURST = main("burst");
	public static final ModelLayerLocation WOLF = main("blue_wind_wolf");
	public static final ModelLayerLocation BOAR = main("stone_armor_boar");
	public static final ModelLayerLocation FOX = main("flame_fox");

	private ModEntityModelLayers() {
	}

	private static ModelLayerLocation main(String name) {
		return new ModelLayerLocation(CultivationMod.id(name), "main");
	}

	public static void register() {
		ModelLayerRegistry.registerModelLayer(ORB, OrbModel::createLayer);
		ModelLayerRegistry.registerModelLayer(CRESCENT, CrescentModel::createLayer);
		ModelLayerRegistry.registerModelLayer(BURST, BurstModel::createLayer);
		ModelLayerRegistry.registerModelLayer(WOLF, BeastModel::wolfLayer);
		ModelLayerRegistry.registerModelLayer(BOAR, BeastModel::boarLayer);
		ModelLayerRegistry.registerModelLayer(FOX, BeastModel::foxLayer);
	}
}
