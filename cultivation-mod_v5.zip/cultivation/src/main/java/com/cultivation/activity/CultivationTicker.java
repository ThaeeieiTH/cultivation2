package com.cultivation.activity;

import com.cultivation.CultivationConfig;
import com.cultivation.data.CultivationStore;
import com.cultivation.progression.ProgressionService;
import com.cultivation.qi.QiService;
import com.cultivation.skill.SkillService;
import com.cultivation.skill.SkillStore;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Once per second: natural Qi regeneration, plus meditation (sneaking while standing still), which
 * boosts Qi regeneration and grants cultivation experience. Pending data is synced once per tick.
 */
public final class CultivationTicker {
	private static final Map<UUID, double[]> LAST_POSITION = new HashMap<>();

	private CultivationTicker() {
	}

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(CultivationTicker::onTick);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			UUID id = handler.getPlayer().getUUID();
			LAST_POSITION.remove(id);
			CultivationStore.forget(id);
			SkillStore.forget(id);
			SkillService.forget(id);
		});
	}

	private static void onTick(MinecraftServer server) {
		if (server.getTickCount() % CultivationConfig.TICKS_PER_SECOND == 0) {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				processSecond(player);
			}
		}
		CultivationStore.flush(server);
		SkillStore.flush(server);
	}

	private static void processSecond(ServerPlayer player) {
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}
		boolean meditating = isMeditating(player);
		QiService.regenerate(player, meditating ? CultivationConfig.MEDITATION_QI_MULTIPLIER : 1);
		if (meditating) {
			long required = CultivationStore.get(player).requiredExperience();
			long gain = Math.max(CultivationConfig.MEDITATION_EXP_MIN, required / CultivationConfig.MEDITATION_EXP_DIVISOR);
			ProgressionService.addExperience(player, gain);
		}
	}

	private static boolean isMeditating(ServerPlayer player) {
		double[] now = {player.getX(), player.getY(), player.getZ()};
		double[] before = LAST_POSITION.put(player.getUUID(), now);
		if (before == null) {
			return false;
		}
		double dx = now[0] - before[0];
		double dy = now[1] - before[1];
		double dz = now[2] - before[2];
		boolean still = dx * dx + dy * dy + dz * dz <= CultivationConfig.MEDITATION_MAX_MOVE_SQ;
		return still && player.isShiftKeyDown() && player.onGround();
	}
}
