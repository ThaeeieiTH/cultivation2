package com.cultivation.progression;

import com.cultivation.data.CultivationData;
import com.cultivation.data.CultivationStore;
import java.util.Locale;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** M key: advance one sub-stage, or break through to the next realm at the perfection stage. */
public final class BreakthroughHandler {
	private BreakthroughHandler() {
	}

	private static String number(long value) {
		return String.format(Locale.ROOT, "%,d", value);
	}

	private static void say(ServerPlayer player, String text) {
		player.sendSystemMessage(Component.literal(text));
	}

	public static void handle(ServerPlayer player) {
		CultivationData before = CultivationStore.get(player);
		ProgressionResult result = before.stage() >= CultivationRules.LAST_STAGE
			? ProgressionService.tryBreakthrough(player)
			: ProgressionService.tryAdvanceStage(player);
		CultivationData after = CultivationStore.get(player);
		switch (result) {
			case ADVANCED -> say(player, "เลื่อนขั้นสำเร็จ! ตอนนี้คือ " + CultivationRules.displayName(after.realm(), after.stage()));
			case BROKE_THROUGH -> say(player, "ทะลวงสำเร็จ! เข้าสู่ " + CultivationRules.displayName(after.realm(), after.stage()));
			case EXPERIENCE_NOT_FULL -> say(player, "ประสบการณ์บ่มเพาะยังไม่เพียงพอ ("
				+ number(after.experience()) + " / " + number(after.requiredExperience()) + ")");
			case QI_NOT_ENOUGH -> say(player, "ปราณไม่เพียงพอสำหรับการทะลวง ต้องใช้ "
				+ number(CultivationRules.breakthroughQiCost(after.realm())) + " (มี " + number(after.qi()) + ")");
			case MAX_REACHED -> say(player, "คุณอยู่ขั้นสูงสุดแล้ว");
			default -> say(player, "ไม่สามารถทะลวงขั้นได้");
		}
	}
}
