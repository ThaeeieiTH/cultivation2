package com.cultivation.loot;

import com.cultivation.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

/**
 * Adds scrolls and swords to vanilla chest loot with low chances. Nothing is ever given
 * automatically; items are only found in chests.
 */
public final class ModLoot {
	private record Entry(ResourceKey<LootTable> table, Item item, float chance) {
	}

	private static final Entry[] ENTRIES = {
		// Common swords
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.PLAIN_IRON_SWORD, 0.20f),
		new Entry(BuiltInLootTables.VILLAGE_WEAPONSMITH, ModItems.PLAIN_IRON_SWORD, 0.30f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.PLAIN_IRON_SWORD, 0.10f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.RUSTY_SWORD, 0.20f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.RUSTY_SWORD, 0.18f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.RUSTY_SWORD, 0.10f),
		new Entry(BuiltInLootTables.JUNGLE_TEMPLE, ModItems.RUSTY_SWORD, 0.10f),
		// Rarer swords
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.BLACK_IRON_SWORD, 0.08f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.BLACK_IRON_SWORD, 0.06f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.SILVER_SWORD, 0.04f),
		new Entry(BuiltInLootTables.STRONGHOLD_CORRIDOR, ModItems.SILVER_SWORD, 0.04f),
		new Entry(BuiltInLootTables.VILLAGE_WEAPONSMITH, ModItems.SILVER_SWORD, 0.05f),
		// Scrolls
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.QI_BOLT_MANUAL, 0.15f),
		new Entry(BuiltInLootTables.ABANDONED_MINESHAFT, ModItems.QI_BOLT_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.DESERT_PYRAMID, ModItems.QI_BOLT_MANUAL, 0.10f),
		new Entry(BuiltInLootTables.SIMPLE_DUNGEON, ModItems.AZURE_SWORD_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.JUNGLE_TEMPLE, ModItems.AZURE_SWORD_MANUAL, 0.12f),
		new Entry(BuiltInLootTables.STRONGHOLD_LIBRARY, ModItems.AZURE_SWORD_MANUAL, 0.15f),
	};

	private ModLoot() {
	}

	public static void register() {
		LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
			if (!source.isBuiltin()) {
				return;
			}
			for (Entry entry : ENTRIES) {
				if (entry.table().equals(key)) {
					LootPool.Builder pool = LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0f))
						.when(LootItemRandomChanceCondition.randomChance(entry.chance()))
						.add(LootItem.lootTableItem(entry.item()));
					tableBuilder.withPool(pool);
				}
			}
		});
	}
}
