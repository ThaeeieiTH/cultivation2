package com.cultivation.network;

import com.cultivation.data.CultivationStore;
import com.cultivation.progression.BreakthroughHandler;
import com.cultivation.skill.SkillService;
import com.cultivation.skill.SkillStore;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;

/** Server-side synchronisation and request handling. Every request is validated on the server. */
public final class CultivationNetworking {
	private CultivationNetworking() {
	}

	public static void registerPayloads() {
		PayloadTypeRegistry.clientboundPlay().register(CultivationSyncPayload.TYPE, CultivationSyncPayload.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(SkillSyncPayload.TYPE, SkillSyncPayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(ActionPayload.TYPE, ActionPayload.CODEC);
	}

	public static void registerEvents() {
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sendAll(handler.getPlayer()));
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> sendAll(newPlayer));
		ServerPlayNetworking.registerGlobalReceiver(ActionPayload.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			switch (payload.action()) {
				case ActionPayload.BREAKTHROUGH -> BreakthroughHandler.handle(player);
				case ActionPayload.NEXT_SKILL -> SkillService.selectNext(player);
				case ActionPayload.USE_SKILL -> SkillService.use(player);
				default -> {
				}
			}
		});
	}

	public static void sendAll(ServerPlayer player) {
		send(player);
		sendSkills(player);
	}

	public static void send(ServerPlayer player) {
		ServerPlayNetworking.send(player, CultivationSyncPayload.from(CultivationStore.get(player)));
	}

	public static void sendSkills(ServerPlayer player) {
		ServerPlayNetworking.send(player, SkillSyncPayload.from(SkillStore.get(player)));
	}
}
