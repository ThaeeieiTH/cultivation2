package com.cultivation.item;

import com.cultivation.CultivationMod;
import com.cultivation.skill.SkillType;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.ItemLore;

/** All items added by the mod. Swords are usable at every cultivation level. */
public final class ModItems {
	// --- Skill manuals ---
	public static final Item QI_BOLT_MANUAL = manual("qi_bolt_manual", SkillType.QI_BOLT);
	public static final Item AZURE_SWORD_MANUAL = manual("azure_sword_manual", SkillType.AZURE_SWORD);

	// --- First-tier swords (damage = total damage dealt, durability as specified) ---
	public static final Item PLAIN_IRON_SWORD = sword("plain_iron_sword", 5, 250, Rarity.COMMON,
		"กระบี่สามัญ", "กระบี่เหล็กพื้นฐานที่ช่างตีเหล็กทั่วไปสร้างขึ้น แข็งแรงและใช้งานง่าย");
	public static final Item RUSTY_SWORD = sword("rusty_sword", 4, 150, Rarity.COMMON,
		"กระบี่สามัญ", "กระบี่เก่าที่ผ่านการใช้งานมานาน ใบกระบี่มีสนิมและร่องรอยการสึกหรอ");
	public static final Item BRONZE_SWORD = sword("bronze_sword", 5, 220, Rarity.COMMON,
		"กระบี่สามัญ", "กระบี่ที่ตีขึ้นจากสำริด มีน้ำหนักสมดุลและเหมาะกับการฝึกกระบี่");
	public static final Item BLACK_IRON_SWORD = sword("black_iron_sword", 6, 280, Rarity.UNCOMMON,
		"กระบี่สามัญ", "กระบี่ที่ผ่านการตีขึ้นรูปด้วยเหล็กสีเข้ม มีความทนทานมากกว่ากระบี่ทั่วไป");
	public static final Item SILVER_SWORD = sword("silver_sword", 6, 240, Rarity.UNCOMMON,
		"กระบี่สามัญ", "กระบี่ใบสีเงินที่มีน้ำหนักเบา เหมาะสำหรับการฟาดฟันอย่างรวดเร็ว");

	// --- Beast drops ---
	public static final Item WOLF_FANG = material("wolf_fang", "เขี้ยวหมาป่า", "เขี้ยวแหลมคมของหมาป่าวายุคราม");
	public static final Item WIND_CORE = material("wind_core", "แก่นวายุ", "แก่นพลังลมที่เหลือจากหมาป่าวายุคราม");
	public static final Item STONE_FANG = material("stone_fang", "เขี้ยวศิลา", "เขี้ยวแข็งดั่งหินของหมูป่าเกราะศิลา");
	public static final Item STONE_ARMOR_SHARD = material("stone_armor_shard", "เศษเกราะหิน", "เศษเกราะหินที่หลุดจากหมูป่าเกราะศิลา");
	public static final Item FLAME_CORE = material("flame_core", "แก่นเพลิง", "แก่นพลังเพลิงที่ยังอุ่นอยู่ จากจิ้งจอกเพลิง");
	public static final Item SPIRIT_FOX_FUR = material("spirit_fox_fur", "ขนจิ้งจอกอสูร", "ขนนุ่มสีส้มแดงของจิ้งจอกเพลิง");

	private ModItems() {
	}

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties properties) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, CultivationMod.id(name));
		return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(properties.setId(key)));
	}

	private static Item.Properties withLore(Item.Properties properties, String... lines) {
		List<Component> components = new ArrayList<>();
		for (String line : lines) {
			components.add(Component.literal(line).withStyle(ChatFormatting.GRAY));
		}
		return properties.component(DataComponents.LORE, new ItemLore(components));
	}

	private static Item manual(String name, SkillType skill) {
		Item.Properties properties = withLore(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON),
			"วิชา: " + skill.thaiName() + " (" + skill.kind() + ")",
			"ระดับคัมภีร์: สร้างลมปราณ",
			"ระดับพลังที่ต้องมี: สร้างลมปราณ",
			skill.description(),
			"คลิกขวาเพื่อเรียนรู้วิชา");
		return register(name, props -> new ManualItem(props, skill), properties);
	}

	private static Item sword(String name, int damage, int durability, Rarity rarity, String tier, String description) {
		ToolMaterial material = new ToolMaterial(
			BlockTags.INCORRECT_FOR_IRON_TOOL, durability, 6.0f, 0.0f, 10, ItemTags.IRON_TOOL_MATERIALS);
		// Player base damage is 1, so the sword contributes (damage - 1).
		Item.Properties properties = withLore(new Item.Properties().sword(material, damage - 1.0f, -2.4f).rarity(rarity),
			"ระดับ: " + tier,
			"ความเสียหาย: " + damage + "  ความทนทาน: " + durability,
			description,
			"ผู้ฝึกตนทุกระดับพลังใช้ได้");
		return register(name, Item::new, properties);
	}

	private static Item material(String name, String thaiName, String description) {
		return register(name, Item::new, withLore(new Item.Properties(), description));
	}

	public static void init() {
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
			tab.accept(PLAIN_IRON_SWORD);
			tab.accept(RUSTY_SWORD);
			tab.accept(BRONZE_SWORD);
			tab.accept(BLACK_IRON_SWORD);
			tab.accept(SILVER_SWORD);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tab -> {
			tab.accept(QI_BOLT_MANUAL);
			tab.accept(AZURE_SWORD_MANUAL);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(tab -> {
			tab.accept(WOLF_FANG);
			tab.accept(WIND_CORE);
			tab.accept(STONE_FANG);
			tab.accept(STONE_ARMOR_SHARD);
			tab.accept(FLAME_CORE);
			tab.accept(SPIRIT_FOX_FUR);
		});
	}
}
